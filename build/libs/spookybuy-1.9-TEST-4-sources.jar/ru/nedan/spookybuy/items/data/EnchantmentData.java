package ru.nedan.spookybuy.items.data;

import net.minecraft.class_1887;
import org.jetbrains.annotations.NotNull;

public record EnchantmentData(class_1887 enchantment, int level) {
    public static EnchantmentData of(class_1887 enchantment, int level) {
        return new EnchantmentData(enchantment, level);
    }

    @Override
    public @NotNull String toString() {
        return "EnchantmentData{" +
                "enchantment='" + enchantment + '\'' +
                ", level='" + level + '\'' +
                '}';
    }
}
