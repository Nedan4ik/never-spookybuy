package ru.nedan.spookybuy.items.data;

import lombok.Getter;
import net.minecraft.class_1320;
import net.minecraft.class_1322;

@Getter
public class AttributeData {
    private final class_1320 attribute;
    private final double value;
    private final class_1322.class_1323 type;

    public AttributeData(class_1320 attribute, double value, class_1322.class_1323 type) {
        this.attribute = attribute;
        this.value = value;
        this.type = type;
    }

    public static AttributeData of(class_1320 attribute, double value, class_1322.class_1323 type) {
        return new AttributeData(attribute, value, type);
    }
}
