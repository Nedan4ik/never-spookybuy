package ru.nedan.spookybuy.items.data;

import net.minecraft.class_1291;

public record EffectData(class_1291 effectType, int duration, int amplifier) {
    public static EffectData of(class_1291 effectType, int seconds, int amplifier) {
        return new EffectData(effectType, seconds * 20, amplifier);
    }

    public static EffectData instant(class_1291 effectType, int amplifier) {
        return new EffectData(effectType, 1, amplifier);
    }
}
