package ru.nedan.spookybuy.items;

import ru.nedan.spookybuy.items.data.AttributeData;
import ru.nedan.spookybuy.items.data.EffectData;
import ru.nedan.spookybuy.items.data.EnchantmentData;
import ru.nedan.spookybuy.items.impl.EnchantedItem;
import ru.nedan.spookybuy.items.impl.PotionItem;
import ru.nedan.spookybuy.items.impl.SphereItem;
import ru.nedan.spookybuy.items.impl.TalismanItem;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import net.minecraft.class_1792;
import net.minecraft.class_1799;

import static net.minecraft.class_1893.*;
import static net.minecraft.class_1322.class_1323.*;
import static net.minecraft.class_5134.*;
import static net.minecraft.class_1294.*;
import static net.minecraft.class_1802.*;

public class ItemStorage {
    public static final List<CollectItem> ALL = new ArrayList<>();
    private static final List<EnchantmentData> DEFAULT_FOR_ARMOR;

    static {
        DEFAULT_FOR_ARMOR = Arrays.asList(
                EnchantmentData.of(field_9119, 5),
                EnchantmentData.of(field_9111, 5),
                EnchantmentData.of(field_9096, 5),
                EnchantmentData.of(field_9107, 5),
                EnchantmentData.of(field_9101, 1),
                EnchantmentData.of(field_9095, 5)
        );

        reload();
    }

    public static void reload() {
        ALL.clear();

        ALL.addAll(Arrays.asList(
                new CollectItem()
                        .setName("Зачарованное золотое яблоко")
                        .setItem(field_8367),
                new CollectItem()
                        .setName("Золотое яблоко")
                        .setItem(field_8463),
                new EnchantedItem(contact(EnchantmentData.of(field_9105, 1),
                        EnchantmentData.of(field_9127, 3)))
                        .setItem(field_22027)
                        .setName("Шлем крушителя")
                        .setMaxSellPrice(15000000),
                new EnchantedItem(contact())
                        .setMaxSellPrice(15000000)
                        .setName("Нагрудник крушителя")
                        .setItem(field_22028),
                new EnchantedItem(contact())
                        .setMaxSellPrice(15000000)
                        .setName("Поножи крушителя")
                        .setItem(field_22029),
                new EnchantedItem(contact(EnchantmentData.of(field_9128, 3),
                        EnchantmentData.of(field_9129, 4),
                        EnchantmentData.of(field_23071, 3)))
                        .setMaxSellPrice(15000000)
                        .setName("Ботинки крушителя")
                        .setItem(field_22030),
                new EnchantedItem(create(EnchantmentData.of(field_9117, 1),
                        EnchantmentData.of(field_9124, 2),
                        EnchantmentData.of(field_9106, 5),
                        EnchantmentData.of(field_9120, 3),
                        EnchantmentData.of(field_9101, 1),
                        EnchantmentData.of(field_9118, 7),
                        EnchantmentData.of(field_9119, 5)),
                        "Детекция III",
                        "Яд III",
                        "Возвращение",
                        "Вампиризм II",
                        "Опытный III",
                        "Окисление II",
                        "Ступор III",
                        "Притяжение II",
                        "Подрывник",
                        "Скаут III")
                        .setName("Трезубец крушителя")
                        .setItem(field_8547),
                new EnchantedItem(create(EnchantmentData.of(field_9112, 7),
                        EnchantmentData.of(field_9118, 7),
                        EnchantmentData.of(field_9123, 7),
                        EnchantmentData.of(field_9124, 2),
                        EnchantmentData.of(field_9110, 5),
                        EnchantmentData.of(field_9101, 1),
                        EnchantmentData.of(field_9115, 3),
                        EnchantmentData.of(field_9119, 5)),
                        "Вампиризм II", "Детекция III", "Опытный III", "Яд III", "Окисление II")
                        .setName("Меч крушителя")
                        .setItem(field_22022)
                        .setMaxSellPrice(15000000),
                new EnchantedItem(create(EnchantmentData.of(field_9108, 1),
                        EnchantmentData.of(field_9132, 5),
                        EnchantmentData.of(field_9098, 3),
                        EnchantmentData.of(field_9101, 1),
                        EnchantmentData.of(field_9119, 3)))
                        .setName("Арбалет крушителя")
                        .setItem(field_8399),
                new EnchantedItem(create(EnchantmentData.of(field_9131, 10),
                        EnchantmentData.of(field_9130, 5),
                        EnchantmentData.of(field_9101, 1),
                        EnchantmentData.of(field_9119, 5)),
                        "Магнит", "Пингер", "Паутина", "Бульдозер II", "Авто-Плавка", "Опытный III")
                        .setName("Кирка крушителя")
                        .setMaxSellPrice(25000000)
                        .setItem(field_22024),
                new EnchantedItem(create(EnchantmentData.of(field_9118, 8)))
                        .setName("Заострённый меч")
                        .setItem(field_22022),
                new CollectItem()
                        .setName("Божья Аура")
                        .setItem(field_8614)
                        .setTag("effect-item-god"),
                new CollectItem()
                        .setName("Драконий скин")
                        .setItem(field_8407)
                        .setStack(enchant(field_8407))
                        .setTag("trap-skin-item-dragon"),
                new CollectItem()
                        .setName("Неизбежный скин")
                        .setItem(field_8407)
                        .setStack(enchant(field_8407))
                        .setTag("trap-skin-item-inevitable"),
                new CollectItem()
                        .setName("Серебро")
                        .setItem(field_8675)
                        .setTag("\"spookystash:currency\":\"silver\""),
                new CollectItem()
                        .setName("Алмаз")
                        .setItem(field_8477),
                new CollectItem()
                        .setName("Книга починка")
                        .setItem(field_8598)
                        .addEnchantments(EnchantmentData.of(field_9101, 1)),
                new CollectItem()
                        .setName("Элитры")
                        .setItem(field_8833)
                        .addEnchantments(
                                EnchantmentData.of(field_9119, 5),
                                EnchantmentData.of(field_9101, 1)
                        ),
                new CollectItem()
                        .setName("Божье касание")
                        .setItem(field_8335)
                        .setStack(enchant(field_8335))
                        .setTag("spawner-item-spawner-break")
                        .setMaxSellPrice(25000000),
                new CollectItem()
                        .setName("Мощный удар")
                        .setItem(field_8335)
                        .setStack(enchant(field_8335))
                        .setTag("bedrock-item-bedrock-break")
                        .setMaxSellPrice(25000000),
                new CollectItem()
                        .setName("Молот Тора")
                        .setItem(field_22024)
                        .setStack(enchant(field_22024))
                        .setTag("radius-item-mega-buldozer")
                        .setMaxSellPrice(25000000),
                new CollectItem()
                        .setName("Трапка")
                        .setItem(field_22021)
                        .setTag("schematic-item-trap"),
                new CollectItem()
                        .setName("Отмычка к сферам")
                        .setItem(field_8366)
                        .setStack(enchant(field_8366))
                        .setTag("spheres"),
                new CollectItem()
                        .setName("Спавнер")
                        .setItem(field_8849)
                        .setMaxSellPrice(40000000),
                new CollectItem()
                        .setName("Маяк")
                        .setItem(field_8668),
                new CollectItem()
                        .setName("Череп визер-скелета")
                        .setItem(field_8791),
                new CollectItem()
                        .setName("Голова дракона")
                        .setItem(field_8712),
                new CollectItem()
                        .setName("Таер блэк")
                        .setItem(field_8626)
                        .setTag("tnt-item-black"),
                new CollectItem()
                        .setName("Таер вайт")
                        .setItem(field_8626)
                        .setTag("tnt-item-white"),
                new PotionItem(true, 16738740,
                        EffectData.of(field_5909, 10, 8),
                        EffectData.of(field_5904, 20, 4),
                        EffectData.of(field_5919, 5, 8),
                        EffectData.of(field_5912, 180, 0))
                        .setName("Хлопушка"),
                new PotionItem(true, 16777215,
                        EffectData.of(field_5924, 45, 0), EffectData.of(field_5905, 600, 1), EffectData.instant(field_5915, 1))
                        .setName("Святая вода"),
                new PotionItem(true, 10040115,
                        EffectData.of(field_5910, 30, 4), EffectData.of(field_5909, 30, 3))
                        .setName("Зелье гнева"),
                new PotionItem(true, 65535,
                        EffectData.of(field_5907, 600, 0), EffectData.of(field_5918, 600, 0), EffectData.of(field_5914, 60, 2), EffectData.of(field_5905, 900, 2))
                        .setName("Зелье палладина"),
                new PotionItem(true, 3355443,
                        EffectData.of(field_5910, 60, 3), EffectData.of(field_5904, 300, 2), EffectData.of(field_5917, 60, 0), EffectData.instant(field_5921, 1))
                        .setName("Зелье ассасина"),
                new PotionItem(true, 3329330,
                        EffectData.of(field_5899, 20, 0), EffectData.of(field_5920, 20, 0), EffectData.of(field_5909, 20, 2), EffectData.of(field_5903, 20, 4), EffectData.of(field_5912, 20, 0))
                        .setName("Зелье радиации"),
                new PotionItem(true, 4737096,
                        EffectData.of(field_5911, 90, 0), EffectData.of(field_5901, 10, 0), EffectData.of(field_5920, 90, 2), EffectData.of(field_5919, 10, 0))
                        .setName("Снотворное"),
                new SphereItem("ewogICJ0aW1lc3RhbXAiIDogMTc1MDI3ODY0MTkwMCwKICAicHJvZmlsZUlkIiA6ICIxNzRjZmRiNGEzY2I0M2I1YmZjZGU0MjRjM2JiMmM2ZSIsCiAgInByb2ZpbGVOYW1lIiA6ICJtYXJhZWwxOCIsCiAgInNpZ25hdHVyZVJlcXVpcmVkIiA6IHRydWUsCiAgInRleHR1cmVzIiA6IHsKICAgICJTS0lOIiA6IHsKICAgICAgInVybCIgOiAiaHR0cDovL3RleHR1cmVzLm1pbmVjcmFmdC5uZXQvdGV4dHVyZS9lN2E3YWU3Y2RjZjYxNmU4YjdhNDIyMWE2MjFiMjQzNTc1M2M2MGVkNmEyNThlYTA2MGRhZTMwMDJmZmU5ZTI4IiwKICAgICAgIm1ldGFkYXRhIiA6IHsKICAgICAgICAibW9kZWwiIDogInNsaW0iCiAgICAgIH0KICAgIH0KICB9Cn0=", new int[]{-1582985800,1375286202,-1125478243,595287099},
                        AttributeData.of(field_23719, 0.07, field_6330), AttributeData.of(field_23716, -4, field_6328), AttributeData.of(field_23723, 0.13, field_6330), AttributeData.of(field_23724, 1.5, field_6328), AttributeData.of(field_23721, 2.5, field_6328))
                        .setName("Сфера Хаоса"),
                new SphereItem("ewogICJ0aW1lc3RhbXAiIDogMTc1MDI3ODYwODUyOCwKICAicHJvZmlsZUlkIiA6ICJkMTQ4NjFiM2UwZmM0Njk5OTFlMTcyNTllMzdiZjZhZCIsCiAgInByb2ZpbGVOYW1lIiA6ICJyYXhpdG9jbCIsCiAgInNpZ25hdHVyZVJlcXVpcmVkIiA6IHRydWUsCiAgInRleHR1cmVzIiA6IHsKICAgICJTS0lOIiA6IHsKICAgICAgInVybCIgOiAiaHR0cDovL3RleHR1cmVzLm1pbmVjcmFmdC5uZXQvdGV4dHVyZS83NzFhOWE0OThiNGZhNWVjNDkzNjJmOWJjODhlZGE0ZjUyYjA0ZGU0OWQ3NWFhM2NhMzMyYTFmZWExYWEwZTU3IiwKICAgICAgIm1ldGFkYXRhIiA6IHsKICAgICAgICAibW9kZWwiIDogInNsaW0iCiAgICAgIH0KICAgIH0KICB9Cn0=", new int[]{-2101547208,2058105556,-1495491604,1400184240},
                        AttributeData.of(field_23723, 0.15, field_6330), AttributeData.of(field_23721, 2, field_6328))
                        .setName("Сфера Сатира"),
                new SphereItem("ewogICJ0aW1lc3RhbXAiIDogMTc1MDM0MzgzNDkzMCwKICAicHJvZmlsZUlkIiA6ICI1MzUzNWIxN2M0ZDY0NWQ0YWUwY2U2ZjM4Zjk0NTFjYSIsCiAgInByb2ZpbGVOYW1lIiA6ICJVYml2aXMiLAogICJzaWduYXR1cmVSZXF1aXJlZCIgOiB0cnVlLAogICJ0ZXh0dXJlcyIgOiB7CiAgICAiU0tJTiIgOiB7CiAgICAgICJ1cmwiIDogImh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvNTQxMWFjMTczODFiOWZjZTliYWIzYzcyYWZkYjdmMTk4NTcwZGFmNDczMmJkODExZDMxYzIyN2Q4MGZhMzliMSIsCiAgICAgICJtZXRhZGF0YSIgOiB7CiAgICAgICAgIm1vZGVsIiA6ICJzbGltIgogICAgICB9CiAgICB9CiAgfQp9", new int[]{-1896649230,-398640094,-1320063783,945063190},
                        AttributeData.of(field_23719, 0.1, field_6330), AttributeData.of(field_23716, 4, field_6328), AttributeData.of(field_23723, 0.1, field_6330), AttributeData.of(field_23724, 1, field_6328))
                        .setName("Сфера Бестии"),
                new SphereItem("ewogICJ0aW1lc3RhbXAiIDogMTc1MDM0Mzc3NDI1NSwKICAicHJvZmlsZUlkIiA6ICJhYWMxYjA2OWNkMjE0NWE2ODNlNzQxNzE4MDcxMGU4MiIsCiAgInByb2ZpbGVOYW1lIiA6ICJqdXNhbXUiLAogICJzaWduYXR1cmVSZXF1aXJlZCIgOiB0cnVlLAogICJ0ZXh0dXJlcyIgOiB7CiAgICAiU0tJTiIgOiB7CiAgICAgICJ1cmwiIDogImh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvYzE2YWRjNmJhZmNiNTdmZDcwN2RlZTdkZDZhNzM2ZmUxMjY3MTFkNTNhMWZkNmNlNzg5ZGE0MWIzYmUxM2YyYSIsCiAgICAgICJtZXRhZGF0YSIgOiB7CiAgICAgICAgIm1vZGVsIiA6ICJzbGltIgogICAgICB9CiAgICB9CiAgfQp9", new int[]{2124864246,465122563,-1511078600,-555424585},
                        AttributeData.of(field_23716, -2, field_6328), AttributeData.of(field_23721, 6, field_6328), AttributeData.of(field_23724, -2, field_6328))
                        .setName("Сфера Ареса"),
                new SphereItem("ewogICJ0aW1lc3RhbXAiIDogMTc1MDI3ODUzMjE4MywKICAicHJvZmlsZUlkIiA6ICI1OGZmZWI5NTMxNGQ0ODcwYTQwYjVjYjQyZDRlYTU5OCIsCiAgInByb2ZpbGVOYW1lIiA6ICJTa2luREJuZXQiLAogICJzaWduYXR1cmVSZXF1aXJlZCIgOiB0cnVlLAogICJ0ZXh0dXJlcyIgOiB7CiAgICAiU0tJTiIgOiB7CiAgICAgICJ1cmwiIDogImh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvM2UzYzExOGQ2OTZkOTEwZTU0ZGUwMmNhNGQ4MDc1NDNmOWIxOGMwMDhjOTgzOGQyZmY2OTM3NzYyMmZiMWQzMiIsCiAgICAgICJtZXRhZGF0YSIgOiB7CiAgICAgICAgIm1vZGVsIiA6ICJzbGltIgogICAgICB9CiAgICB9CiAgfQp9", new int[]{-1308798306,1128020291,-1307054059,-1317369961},
                        AttributeData.of(field_23716, 4, field_6328), AttributeData.of(field_23724, 2, field_6328))
                        .setName("Сфера Гидры"),
                new SphereItem("ewogICJ0aW1lc3RhbXAiIDogMTc1MDI3ODU4MjQ5MSwKICAicHJvZmlsZUlkIiA6ICJhZWNkODIxZTQyYzE0ZDJlOThmNTA1OTg1MWI5OWMzNyIsCiAgInByb2ZpbGVOYW1lIiA6ICJSb2RyaVgyMDc1IiwKICAic2lnbmF0dXJlUmVxdWlyZWQiIDogdHJ1ZSwKICAidGV4dHVyZXMiIDogewogICAgIlNLSU4iIDogewogICAgICAidXJsIiA6ICJodHRwOi8vdGV4dHVyZXMubWluZWNyYWZ0Lm5ldC90ZXh0dXJlL2M2ODAzZTZkNTY2N2EyZDYxMDYyOGJjM2IzMmY4NjNjZGE0OTVjNDY1NjE2ZGU2NTVjYjMyOTkzM2I2MWFmNzciLAogICAgICAibWV0YWRhdGEiIDogewogICAgICAgICJtb2RlbCIgOiAic2xpbSIKICAgICAgfQogICAgfQogIH0KfQ==", new int[]{1858435695,-517000716,-1346102858,1389869685},
                        AttributeData.of(field_23721, 2, field_6328), AttributeData.of(field_23716, 2, field_6328))
                        .setName("Сфера Икара"),
                new SphereItem("eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvODFlOTY5ODQ1OGI3ODQxYzk2YWU0ZjI0ZWM4NGFlMDE3MjQxMDA2NDFjNTY0ZTJhN2IxODVmNDA2ZThlZDIzIn19fQ==", new int[]{654012711,1596536861,-2049048826,-850597571},
                        AttributeData.of(field_23725, 2.5, field_6328), AttributeData.of(field_23719, -0.15, field_6330), AttributeData.of(field_23724, 2.5, field_6328))
                        .setName("Сфера Титана"),
                new SphereItem("ewogICJ0aW1lc3RhbXAiIDogMTc1MDM0Mzg2MTE4NywKICAicHJvZmlsZUlkIiA6ICJlZGUyYzdhMGFjNjM0MTNiYjA5ZDNmMGJlZTllYzhlYyIsCiAgInByb2ZpbGVOYW1lIiA6ICJ0aGVEZXZKYWRlIiwKICAic2lnbmF0dXJlUmVxdWlyZWQiIDogdHJ1ZSwKICAidGV4dHVyZXMiIDogewogICAgIlNLSU4iIDogewogICAgICAidXJsIiA6ICJodHRwOi8vdGV4dHVyZXMubWluZWNyYWZ0Lm5ldC90ZXh0dXJlLzZlNGUyZjEwNDdmM2VjNmU5ZTQ1OTE4NDczOWUzM2I3YzFmYzYzYWQ4MjAyYmRhYjlmMDI0NTA4YWRkMjNlNWIiLAogICAgICAibWV0YWRhdGEiIDogewogICAgICAgICJtb2RlbCIgOiAic2xpbSIKICAgICAgfQogICAgfQogIH0KfQ==", new int[]{-122635583,2062758360,-2035264015,874042263},
                        AttributeData.of(field_23726, 1, field_6328), AttributeData.of(field_23716, 2, field_6328))
                        .setName("Сфера Эрида"),
                new TalismanItem(AttributeData.of(field_23716, 4, field_6328), AttributeData.of(field_23721, 3, field_6328), AttributeData.of(field_23724, 2, field_6328), AttributeData.of(field_23725, 2, field_6328))
                        .setName("Талисман Крушителя"),
                new TalismanItem(AttributeData.of(field_23716, -4, field_6328), AttributeData.of(field_23719, 0.1, field_6330), AttributeData.of(field_23721, 7, field_6328))
                        .setName("Талисман Карателя"),
                new TalismanItem(AttributeData.of(field_23716, 2, field_6328), AttributeData.of(field_23719, 0.1, field_6330), AttributeData.of(field_23723, 0.1, field_6330), AttributeData.of(field_23721, 4, field_6328), AttributeData.of(field_23724, -3, field_6328))
                        .setName("Талисман Раздора"),
                new TalismanItem(AttributeData.of(field_23716, -4, field_6328), AttributeData.of(field_23721, 2, field_6328), AttributeData.of(field_23724, 2, field_6328))
                        .setName("Талисман Тирана"),
                new TalismanItem(AttributeData.of(field_23716, -4, field_6328), AttributeData.of(field_23721, 5, field_6328))
                        .setName("Талисман Ярости"),
                new TalismanItem(AttributeData.of(field_23716, 2, field_6328), AttributeData.of(field_23723, 0.15, field_6330), AttributeData.of(field_23719, 0.15, field_6330))
                        .setName("Талисман Вихря"),
                new TalismanItem(AttributeData.of(field_23716, 1.5, field_6328), AttributeData.of(field_23724, 1.5, field_6328))
                        .setName("Талисман Мрака"),
                new TalismanItem(AttributeData.of(field_23723, 0.1, field_6330), AttributeData.of(field_23721, 2.5, field_6328))
                        .setName("Талисман Демона")
        ));
    }

    private static class_1799 enchant(class_1792 item) {
        class_1799 stack = new class_1799(item);
        stack.method_7978(field_9119, 1);

        return stack;
    }

    private static List<EnchantmentData> contact(EnchantmentData... enchantmentData) {
        List<EnchantmentData> data = new ArrayList<>(create(enchantmentData));
        data.addAll(DEFAULT_FOR_ARMOR);

        return data;
    }

    private static List<EnchantmentData> create(EnchantmentData... enchantmentData) {
        return Arrays.asList(enchantmentData);
    }
}
