package ru.nedan.spookybuy.items.impl;

import ru.nedan.spookybuy.items.CollectItem;
import ru.nedan.spookybuy.items.data.EffectData;

import static net.minecraft.class_1893.field_9119;

import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2487;

public class PotionItem extends CollectItem {

    public PotionItem(boolean splash, int potionColor, EffectData... effects) {
        this.setItem(splash ? class_1802.field_8436 : class_1802.field_8574);

        class_1799 raw = EnchantedItem.enchant(this.getItem());

        this.setStack(getPotionWithColor(raw, potionColor));
        this.addEffects(effects);
    }

    private static class_1799 getPotionWithColor(class_1799 stack, int value) {
        class_2487 nbt = new class_2487();

        nbt.method_10569("CustomPotionColor", value);

        stack.method_7980(nbt);
        stack.method_7978(field_9119, 1);

        return stack;
    }
}
