package ru.nedan.spookybuy.items.impl;

import ru.nedan.spookybuy.items.CollectItem;
import ru.nedan.spookybuy.items.data.EnchantmentData;

import java.util.List;
import net.minecraft.class_1792;
import net.minecraft.class_1799;

import static net.minecraft.class_1893.field_9119;

public class EnchantedItem extends CollectItem {

    public EnchantedItem(List<EnchantmentData> enchantmentData, String... tooltip) {
        this.addEnchantments(enchantmentData.toArray(EnchantmentData[]::new));
        this.addTooltips(tooltip);
    }

    @Override
    public EnchantedItem setItem(class_1792 item) {
        this.setStack(enchant(item));
        super.setItem(item);
        return this;
    }

    public static class_1799 enchant(class_1792 item) {
        class_1799 stack = new class_1799(item);
        stack.method_7978(field_9119, 1);

        return stack;
    }
}
