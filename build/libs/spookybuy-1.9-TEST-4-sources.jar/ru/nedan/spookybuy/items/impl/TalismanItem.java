package ru.nedan.spookybuy.items.impl;

import net.minecraft.class_1802;
import ru.nedan.spookybuy.items.CollectItem;
import ru.nedan.spookybuy.items.data.AttributeData;

public class TalismanItem extends CollectItem {

    public TalismanItem(AttributeData... attributes) {
        this.setItem(class_1802.field_8288);
        this.setStack(EnchantedItem.enchant(class_1802.field_8288));
        this.addAttributes(attributes);
    }
}
