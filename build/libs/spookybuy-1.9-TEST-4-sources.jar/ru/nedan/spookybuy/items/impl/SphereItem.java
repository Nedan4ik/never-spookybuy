package ru.nedan.spookybuy.items.impl;

import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import ru.nedan.spookybuy.items.CollectItem;
import ru.nedan.spookybuy.items.data.AttributeData;

public class SphereItem extends CollectItem {

    public SphereItem(String owner, int[] id, AttributeData... attributes) {
        this.setItem(class_1802.field_8575);
        this.setStack(withSkull(owner, id));

        this.addAttributes(attributes);
    }

    private static class_1799 withSkull(String owner, int[] id) {
        class_1799 stack = new class_1799(class_1802.field_8575);

        class_2487 main = new class_2487();
        class_2487 skullOwner = new class_2487();
        class_2487 properties = new class_2487();
        class_2499 textures = new class_2499();
        class_2487 texture = new class_2487();

        texture.method_10582("Value", owner);
        textures.add(texture);

        properties.method_10566("textures", textures);
        skullOwner.method_10566("Properties", properties);

        skullOwner.method_10539("Id", id);
        main.method_10566("SkullOwner", skullOwner);

        stack.method_7980(main);

        return stack;
    }
}
