package ru.nedan.spookybuy.items;

import com.google.common.collect.Lists;
import com.google.common.collect.Multimap;
import lombok.Getter;
import net.minecraft.class_1293;
import net.minecraft.class_1304;
import net.minecraft.class_1320;
import net.minecraft.class_1322;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1812;
import net.minecraft.class_1836;
import net.minecraft.class_1844;
import net.minecraft.class_1887;
import net.minecraft.class_1890;
import net.minecraft.class_310;
import net.minecraft.class_3544;
import ru.nedan.spookybuy.items.data.AttributeData;
import ru.nedan.spookybuy.items.data.EffectData;
import ru.nedan.spookybuy.items.data.EnchantmentData;

import java.math.BigDecimal;
import java.util.*;
import java.util.function.BiPredicate;
import java.util.stream.Collectors;

@Getter
public class CollectItem {
    private String name;
    private BigDecimal price = new BigDecimal(100);
    private class_1792 item;
    private class_1799 stack;

    private final List<AttributeData> attributesData = Lists.newArrayList();
    private final List<EnchantmentData> enchantmentsData = Lists.newArrayList();
    private final List<String> tooltip = new ArrayList<>();
    private final List<EffectData> effects = new ArrayList<>();
    private String tag;
    private int maxSellPrice = 10000000;

    public static BiPredicate<class_1799, CollectItem> CHECKER = (itemStack, abItem) -> {
        if (itemStack.method_7909() != abItem.getItem()) return false;

        class_310 mc = class_310.method_1551();

        List<String> strings = itemStack.method_7950(mc.field_1724, class_1836.class_1837.field_8935).stream().map(text -> class_3544.method_15440(text.getString())).collect(Collectors.toList());

        boolean tooltipMatch = abItem.tooltip.stream().allMatch(abLine ->
                strings.stream().anyMatch(line -> line.toLowerCase().contains(abLine.toLowerCase()))
        );

        boolean tagMatch = abItem.tag == null || abItem.tag.isEmpty() || (itemStack.method_7969() != null && itemStack.method_7969().toString().toLowerCase().contains(abItem.tag.toLowerCase()));

        Map<class_1887, Integer> stackEnchants = class_1890.method_8222(itemStack);
        boolean enchantmentsMatch = abItem.enchantmentsData.stream()
                .allMatch(entry -> Objects.equals(stackEnchants.getOrDefault(entry.enchantment(), -1), entry.level()));

        boolean effectsMatch = abItem.effects.stream()
                .allMatch(effect -> {
                    if (itemStack.method_7909() instanceof class_1812) {
                        List<class_1293> stackEffects = class_1844.method_8067(itemStack);

                        return stackEffects.stream().anyMatch(e ->
                                e.method_5579().equals(effect.effectType()) &&
                                        e.method_5584() >= effect.duration() &&
                                        e.method_5578() >= effect.amplifier());
                    }
                    return false;
                });

        return effectsMatch && tooltipMatch && tagMatch && enchantmentsMatch && containsAllAttributes(itemStack, abItem.attributesData);
    };

    private static boolean containsAllAttributes(class_1799 stack, List<AttributeData> attributes) {
        Multimap<class_1320, class_1322> stackAttributes = stack.method_7926(class_1304.field_6171);
        return stackAttributes.size() == attributes.size() &&
                stackAttributes.entries().stream()
                        .allMatch(entry -> containsAttribute(entry.getKey(), entry.getValue().method_6186(), entry.getValue().method_6182(), attributes));
    }

    private static boolean containsAttribute(class_1320 attribute, double value, class_1322.class_1323 operation, List<AttributeData> attributes) {
        return attributes.stream()
                .anyMatch(attr -> {
                    boolean matchesAttribute = attr.getAttribute() == attribute;
                    boolean matchesValue = attr.getValue() == value;
                    boolean matchesOperation = attr.getType() == operation;

                    return matchesAttribute && matchesValue && matchesOperation;
                });
    }

    public int getMaxSellPrice() {
        if (maxSellPrice == 10000000) {
            if (this.getItem() == class_1802.field_8288) return 50000000;
            if (this.getItem() == class_1802.field_8575) return 70000000;
        }

        return maxSellPrice;
    }

    public CollectItem setTag(String tag) {
        this.tag = tag;
        return this;
    }

    public CollectItem setStack(class_1799 stack) {
        this.stack = stack;
        return this;
    }

    public class_1799 getStack() {
        if (stack == null) return this.item.method_7854();

        return stack;
    }

    public CollectItem setMaxSellPrice(int maxSellPrice) {
        this.maxSellPrice = maxSellPrice;
        return this;
    }

    public CollectItem setName(String name) {
        this.name = name;
        return this;
    }

    public CollectItem setItem(class_1792 item) {
        this.item = item;
        return this;
    }

    public CollectItem setPrice(BigDecimal price) {
        this.price = price;
        return this;
    }

    public CollectItem addAttributes(AttributeData... attributeData) {
        this.attributesData.addAll(Arrays.asList(attributeData));
        return this;
    }

    public CollectItem addEffects(EffectData... effectData) {
        this.effects.addAll(Arrays.asList(effectData));
        return this;
    }

    public CollectItem addEnchantments(EnchantmentData... enchantmentsData) {
        this.enchantmentsData.addAll(Arrays.asList(enchantmentsData));
        return this;
    }

    public CollectItem addTooltips(String... tooltips) {
        this.tooltip.addAll(Arrays.asList(tooltips));
        return this;
    }
}
