package ru.nedan.spookybuy.mixin;

import org.apache.logging.log4j.Logger;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;
import ru.nedan.spookybuy.util.telegram.TelegramAPI;
import ru.nedan.spookybuy.util.telegram.command.api.TelegramCommandExecutor;

import java.io.File;
import java.util.function.Consumer;
import net.minecraft.class_1011;
import net.minecraft.class_124;
import net.minecraft.class_156;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_2585;
import net.minecraft.class_2588;
import net.minecraft.class_276;
import net.minecraft.class_318;

@Mixin(class_318.class)
public abstract class MixinScreenshotUtils {

    @Shadow
    public static class_1011 takeScreenshot(int width, int height, class_276 framebuffer) {
        return null;
    }

    @Shadow
    private static File getScreenshotFilename(File directory) {
        return null;
    }

    @Shadow @Final private static Logger LOGGER;

    /**
     * @author nedan4ik
     * @reason для отправки в телеграм при необходимости
     */
    @Overwrite
    private static void saveScreenshotInner(File gameDirectory, @Nullable String fileName, int framebufferWidth, int framebufferHeight, class_276 framebuffer, Consumer<class_2561> messageReceiver) {
        class_1011 nativeImage = takeScreenshot(framebufferWidth, framebufferHeight, framebuffer);
        File file = new File(gameDirectory, "screenshots");
        boolean dir = file.mkdir();
        File file2;
        if (fileName == null) {
            file2 = getScreenshotFilename(file);
        } else {
            file2 = new File(file, fileName);
        }

        assert nativeImage != null;
        assert file2 != null;

        class_156.method_27958().execute(() -> {
            try {
                nativeImage.method_4325(file2);
                class_2561 text = (new class_2585(file2.getName())).method_27692(class_124.field_1073).method_27694((style) -> style.method_10958(new class_2558(class_2558.class_2559.field_11746, file2.getAbsolutePath())));

                if (TelegramCommandExecutor.ACTIVE_SCREENSHOT_COMMAND) {
                    new Thread(() -> {
                        try {
                            Thread.sleep(500);

                            TelegramAPI.sendPhoto(file2.getAbsolutePath(), "Скрин из игры:");

                            TelegramCommandExecutor.ACTIVE_SCREENSHOT_COMMAND = false;

                            Thread.sleep(500);
                            boolean del = file2.delete();
                        } catch (Exception e) {
                            e.printStackTrace(System.err);
                        }
                    }).start();
                }

                messageReceiver.accept(new class_2588("screenshot.success", new Object[]{text}));
            } catch (Exception exception) {
                LOGGER.warn("Couldn't save screenshot", exception);
                messageReceiver.accept(new class_2588("screenshot.failure", new Object[]{exception.getMessage()}));
            } finally {
                nativeImage.close();
            }

        });
    }
}
