package ru.nedan.spookybuy.mixin;

import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;

import java.util.Map;
import net.minecraft.class_268;
import net.minecraft.class_269;

@Mixin(class_269.class)
public abstract class MixinScoreboard {

    @Shadow public abstract @Nullable class_268 getPlayerTeam(String playerName);

    @Shadow @Final private Map<String, class_268> teamsByPlayer;

    @Shadow @Final private Map<String, class_268> teams;

    @Shadow public abstract void updateRemovedTeam(class_268 team);

    /**
     * @author nedan4ik
     * @reason чтобы не было спама в консоль
     */
    @Overwrite
    public void removePlayerFromTeam(String playerName, class_268 team) {
        if (this.getPlayerTeam(playerName) == team) {
            this.teamsByPlayer.remove(playerName);
            team.method_1204().remove(playerName);
        }
    }

    /**
     * @author nedan4ik
     * @reason чтобы не было спама в консоль
     */
    @Overwrite
    public void removeTeam(class_268 team) {
        if (team == null) return;

        this.teams.remove(team.method_1197());

        for (String string : team.method_1204()) {
            this.teamsByPlayer.remove(string);
        }

        this.updateRemovedTeam(team);
    }
}
