package ru.nedan.spookybuy.mixin;

import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import com.mojang.datafixers.util.Pair;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.nedan.spookybuy.SpookyBuy;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_2585;
import net.minecraft.class_266;
import net.minecraft.class_267;
import net.minecraft.class_268;
import net.minecraft.class_269;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_329;
import net.minecraft.class_3544;
import net.minecraft.class_437;
import net.minecraft.class_4587;
import net.minecraft.class_5250;

@Mixin(class_329.class)
public abstract class MixinInGameHud {

    @Shadow public abstract class_327 getFontRenderer();

    @Shadow private int scaledHeight;
    @Shadow private int scaledWidth;
    @Shadow @Final private class_310 client;

    /**
     * @author nedan4ik
     * @reason для обновления баланса
     */
    @Overwrite
    private void renderScoreboardSidebar(class_4587 matrices, class_266 objective) {
        class_269 scoreboard = objective.method_1117();
        Collection<class_267> collection = scoreboard.method_1184(objective);
        List<class_267> list = collection.stream().filter((scoreboardPlayerScorex) -> scoreboardPlayerScorex.method_1129() != null && !scoreboardPlayerScorex.method_1129().startsWith("#")).collect(Collectors.toList());
        if (list.size() > 15) {
            collection = Lists.newArrayList(Iterables.skip(list, collection.size() - 15));
        } else {
            collection = list;
        }

        List<Pair<class_267, class_2561>> list2 = Lists.newArrayListWithCapacity(collection.size());
        class_2561 text = objective.method_1114();
        int i = this.getFontRenderer().method_27525(text);
        int j = i;
        int k = this.getFontRenderer().method_1727(": ");

        class_267 scoreboardPlayerScore;
        class_5250 text2;
        for (Iterator<class_267> var11 = ( collection).iterator(); var11.hasNext(); j = Math.max(j, this.getFontRenderer().method_27525(text2) + k + this.getFontRenderer().method_1727(Integer.toString(scoreboardPlayerScore.method_1126())))) {
            scoreboardPlayerScore = var11.next();
            class_268 team = scoreboard.method_1164(scoreboardPlayerScore.method_1129());
            text2 = class_268.method_1142(team, new class_2585(scoreboardPlayerScore.method_1129()));
            list2.add(Pair.of(scoreboardPlayerScore, text2));
        }

        int l = collection.size() * 9;
        int m = this.scaledHeight / 2 + l / 3;
        int o = this.scaledWidth - j - 3;
        int p = 0;
        int q = this.client.field_1690.method_19345(0.3F);
        int r = this.client.field_1690.method_19345(0.4F);

        for (Pair<class_267, class_2561> pair : list2) {
            ++p;
            class_267 scoreboardPlayerScore2 = pair.getFirst();
            class_2561 text3 = pair.getSecond();
            String string = class_124.field_1061 + "" + scoreboardPlayerScore2.method_1126();
            int t = m - p * 9;
            int u = this.scaledWidth - 3 + 2;
            int var10001 = o - 2;
            class_437.method_25294(matrices, var10001, t, u, t + 9, q);
            this.getFontRenderer().method_30883(matrices, text3, (float) o, (float) t, -1);
            this.getFontRenderer().method_1729(matrices, string, (float) (u - this.getFontRenderer().method_1727(string)), (float) t, -1);
            SpookyBuy.getInstance().getAutoBuy().onSBLine(class_3544.method_15440(text3.getString()));
            if (p == collection.size()) {
                var10001 = o - 2;
                class_437.method_25294(matrices, var10001, t - 9 - 1, u, t - 1, r);
                class_437.method_25294(matrices, o - 2, t - 1, u, t, q);
                float var10003 = (float) (o + j / 2 - i / 2);
                this.getFontRenderer().method_30883(matrices, text, var10003, (float) (t - 9), -1);
            }
        }

    }
}
