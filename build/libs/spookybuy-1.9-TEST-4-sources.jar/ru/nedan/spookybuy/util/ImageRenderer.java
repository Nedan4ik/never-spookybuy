package ru.nedan.spookybuy.util;

import com.mojang.blaze3d.systems.RenderSystem;
import lombok.experimental.UtilityClass;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import org.lwjgl.opengl.GL11;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

@UtilityClass
public class ImageRenderer {
    private static final Map<String, class_2960> cache = new HashMap<>();

    static {
        // Регистр текстур из ресурсов потому что нет fabric-resource-loader

        loadOrGetTexture(ImageRenderer.class.getResourceAsStream("/assets/spookybuy/icons/left-slider.png"), "left");
        loadOrGetTexture(ImageRenderer.class.getResourceAsStream("/assets/spookybuy/icons/right-slider.png"), "right");
    }

    public static class_2960 loadOrGetTexture(InputStream input, String name) {
        if (cache.containsKey(name)) {
            return cache.get(name);
        }

        try {
            class_1011 image = class_1011.method_4309(input);
            class_1043 texture = new class_1043(image);
            class_2960 id = class_310.method_1551().method_1531().method_4617(name, texture);
            cache.put(name, id);
            return id;
        } catch (IOException e) {
            e.printStackTrace(System.err);
            return null;
        }
    }

    public static void render(class_2960 textureId, float x, float y, float width, float height, int color) {
        if (textureId == null) return;

        class_310 mc = class_310.method_1551();
        RenderSystem.enableBlend();
        RenderSystem.blendFuncSeparate(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA, GL11.GL_ONE, GL11.GL_ZERO);
        RenderSystem.enableDepthTest();
        mc.method_1531().method_22813(textureId);
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
        class_289 tessellator = class_289.method_1348();
        class_287 bufferBuilder = tessellator.method_1349();
        bufferBuilder.method_1328(GL11.GL_POLYGON, class_290.field_20888);
        bufferBuilder.method_22912(x, y + height, 0).method_1336((color >> 16) & 0xFF, (color >> 8) & 0xFF, color & 0xFF, color >>> 24).method_22913(0, 1 - 0.01f).method_22921(0, 240).method_1344();
        bufferBuilder.method_22912(x + width, y + height, 0).method_1336((color >> 16) & 0xFF, (color >> 8) & 0xFF, color & 0xFF, color >>> 24).method_22913(1, 1 - 0.01f).method_22921(0, 240).method_1344();
        bufferBuilder.method_22912(x + width, y, 0).method_1336((color >> 16) & 0xFF, (color >> 8) & 0xFF, color & 0xFF, color >>> 24).method_22913(1, 0).method_22921(0, 240).method_1344();
        bufferBuilder.method_22912(x, y, 0).method_1336((color >> 16) & 0xFF, (color >> 8) & 0xFF, color & 0xFF, color >>> 24).method_22913(0, 0).method_22921(0, 240).method_1344();
        tessellator.method_1350();
        RenderSystem.disableDepthTest();
        RenderSystem.disableBlend();
    }
}