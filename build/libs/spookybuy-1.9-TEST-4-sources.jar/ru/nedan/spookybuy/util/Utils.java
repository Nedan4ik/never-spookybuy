package ru.nedan.spookybuy.util;

import lombok.experimental.UtilityClass;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_355;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

@UtilityClass
public class Utils {
    private final class_310 mc = class_310.method_1551();

    public String getSeller(class_1799 stack) {
        List<class_2561> itemTooltip = getTooltip(stack);

        for (class_2561 line : itemTooltip) {
            try {
                if (line.getString().contains("☤ Продавец:")) {
                    return line.getString().replace("☤ Продавец: ", "").replaceAll("\\$", "").replaceAll(" ", "");
                }
            } catch (Exception ignored) {
            }
        }

        return "";
    }

    public int getPrice(class_1799 stack) {
        List<class_2561> itemTooltip = getTooltip(stack);

        for (class_2561 line : itemTooltip) {
            try {
                boolean hasByOne = itemTooltip.stream()
                        .anyMatch(text -> text.getString().startsWith("$ Цена за 1 шт."));

                if (line.getString().contains("$ Цена: $") && itemTooltip.get(itemTooltip.indexOf(line) + (hasByOne ? 2 : 1)).getString().contains("☤")) {
                    String part = line.getString().replace("$ Цена: $", "").replaceAll("\\$", "").replaceAll(" ", "").replaceAll(",", "");
                    return Integer.parseInt(part);
                }
            } catch (Exception ignored) {
            }
        }

        return -1;
    }

    public static String getCurrentAnarchy() {
        class_355 playerListHud = mc.inGameHud.getPlayerListHud();
        String anString = "";

        List<Field> textFields = new ArrayList<>();

        for (Field field : playerListHud.getClass().getDeclaredFields()) {
            if (field.getType().equals(class_2561.class)) {
                field.setAccessible(true);
                textFields.add(field);
            }
        }

        for (Field textField : textFields) {
            try {
                class_2561 text = (class_2561) textField.get(playerListHud);

                if (text == null) return "none";

                if (text.getString().contains("Режим: Анархия"))
                    anString = text.getString();

            } catch (IllegalAccessException ignored) {

            }
        }

        if (anString.isEmpty())
            return "none";

        String[] split = anString.split("Режим: ");

        if (split.length < 2)
            return "none";

        return split[1].replaceAll("Анархия-", "");
    }

    public List<class_2561> getTooltip(class_1799 stack) {
        return stack.method_7950(mc.field_1724, mc.field_1690.field_1827 ? class_1836.class_1837.field_8935 : class_1836.class_1837.field_8934);
    }

}
