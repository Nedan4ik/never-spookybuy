package ru.nedan.spookybuy.util.telegram.command.api;

import lombok.AllArgsConstructor;
import lombok.Getter;
import net.minecraft.class_310;
import ru.nedan.spookybuy.event.EventTelegramMessage;

@Getter
@AllArgsConstructor
public abstract class TelegramCommand {
    protected static final class_310 mc = class_310.method_1551();

    private final String name, usage, desc;

    public abstract void execute(EventTelegramMessage event);
}
