package ru.nedan.spookybuy.util.telegram.command.impl;

import net.minecraft.class_318;
import ru.nedan.neverapi.etc.ChatUtility;
import ru.nedan.spookybuy.event.EventTelegramMessage;
import ru.nedan.spookybuy.util.telegram.command.api.TelegramCommand;
import ru.nedan.spookybuy.util.telegram.command.api.TelegramCommandExecutor;

public class ScreenCommand extends TelegramCommand {

    public ScreenCommand() {
        super("Скрин", "скрин", "Скринит игру и отправляет его в чат телеграм");
    }

    @Override
    public void execute(EventTelegramMessage e) {
        TelegramCommandExecutor.ACTIVE_SCREENSHOT_COMMAND = true;
        class_318.method_1659(mc.field_1697, mc.method_22683().method_4489(), mc.method_22683().method_4506(), mc.method_1522(), (p_lambda$onKeyEvent$3_1_) -> ChatUtility.sendMessage("Успешно заскринил!"));
    }

}
