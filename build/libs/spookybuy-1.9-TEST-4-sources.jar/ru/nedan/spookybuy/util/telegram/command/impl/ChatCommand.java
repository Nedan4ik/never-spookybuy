package ru.nedan.spookybuy.util.telegram.command.impl;

import ru.nedan.spookybuy.event.EventTelegramMessage;
import ru.nedan.spookybuy.util.telegram.command.api.TelegramCommand;

public class ChatCommand extends TelegramCommand {

    public ChatCommand() {
        super("Чат", "чат [сообщение]", "Отправляет сообщение в чат майнкрафта");
    }

    @Override
    public void execute(EventTelegramMessage event) {
        String message = event.getMessage().getAsJsonObject("message").get("text").getAsString();
        mc.field_1724.method_3142(message.substring(4));
    }
}
