package ru.nedan.spookybuy.util.autojoin;

import net.minecraft.class_310;
import net.minecraft.class_412;
import net.minecraft.class_419;
import net.minecraft.class_434;
import ru.nedan.neverapi.async.AsyncRunManager;
import ru.nedan.neverapi.event.impl.EventMessage;
import ru.nedan.neverapi.event.impl.EventWindowOpen;

public class AutoJoin {

    private static final class_310 mc = class_310.method_1551();

    public AutoJoin() {
        EventWindowOpen.addListener(EventWindowOpen.class, e -> {
            if (!AutoJoinConfiguration.enabled) return;

            if (e.getScreen() instanceof class_419) {
                AsyncRunManager.waitForClientTicks(AutoJoinConfiguration.longToTicks()).thenRun(() -> {
                    if (mc.field_1755 instanceof class_434 || mc.field_1755 instanceof class_412 || mc.field_1724 != null) return;

                    mc.method_1507(new class_412(e.getScreen(), mc, "spookytime.net", 25565));
                });
            }
        });

        EventMessage.addListener(EventMessage.class, e -> {
            if (!AutoJoinConfiguration.enabled) return;
            if (e.isSend()) return;

            if (e.getMessage().equalsIgnoreCase("[✾] Войдите в игру ⇝ /login <Пароль>")) {
                AsyncRunManager.waitForTicks(20).thenRun(() -> mc.field_1724.method_3142("/l " + AutoJoinConfiguration.PASSWORD));
            } else if (e.getMessage().equalsIgnoreCase("[✾] Успешная авторизация! Приятной игры!")) {
                AsyncRunManager.waitForTicks(20).thenRun(() -> mc.field_1724.method_3142("/an" + AutoJoinConfiguration.ANARCHY_TO_JOIN));
            }
        });


    }
}
