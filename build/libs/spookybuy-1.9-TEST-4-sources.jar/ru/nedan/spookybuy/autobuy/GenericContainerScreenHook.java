package ru.nedan.spookybuy.autobuy;

import com.mojang.blaze3d.systems.RenderSystem;
import ru.nedan.neverapi.NeverAPI;
import ru.nedan.neverapi.gui.Button;
import ru.nedan.neverapi.math.FloatRectangle;
import ru.nedan.neverapi.math.TimerUtility;
import ru.nedan.neverapi.shader.Blur;
import ru.nedan.neverapi.shader.ColorUtility;
import ru.nedan.neverapi.shader.Rounds;
import ru.nedan.spookybuy.SpookyBuy;
import ru.nedan.spookybuy.util.Utils;
import ru.nedan.spookybuy.autobuy.history.HistoryManager;
import ru.nedan.spookybuy.items.CollectItem;

import java.awt.*;
import java.text.NumberFormat;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import net.minecraft.class_1304;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2519;
import net.minecraft.class_2585;
import net.minecraft.class_310;
import net.minecraft.class_3544;
import net.minecraft.class_4587;
import net.minecraft.class_476;

public class GenericContainerScreenHook extends class_476 {
    private static final class_310 mc = class_310.method_1551();

    public GenericContainerScreenHook(class_476 old) {
        super(old.method_17577(), mc.field_1724.field_7514, old.method_25440());
    }

    private final TimerUtility afterInit = new TimerUtility();
    public class_1735 minPrice;
    private Button button = null;

    @Override
    public void method_25423(class_310 client, int width, int height) {
        super.method_25423(client, width, height);

    }

    public static void fill(List<class_1735> slots) {
        for (class_1735 slot : slots) {
            class_1799 stack = slot.method_7677();

            if (stack.method_7960() || stack.method_7947() == 1 || Utils.getPrice(stack) == -1) continue;

            class_2487 compound = stack.method_7948();
            class_2487 display = compound.method_10562("display");
            class_2499 lore = display.method_10573("Lore", 9) ? display.method_10554("Lore", 8) : new class_2499();

            boolean next = true;

            for (int i = 0; i < lore.size(); i++) {
                String line = lore.method_10608(i);

                if (line.contains("Цена за 1 шт.")) {
                    next = false;
                }
            }

            if (!next) continue;

            NumberFormat numberFormat = NumberFormat.getInstance(Locale.US);

            String priceText = "[\"\",{\"italic\":false,\"color\":\"green\",\"text\":\"$\"}," +
                    "{\"italic\":false,\"color\":\"white\",\"text\":\" Цена за 1 шт.: \"}," +
                    "{\"italic\":false,\"color\":\"green\",\"text\":\"$" + numberFormat.format(Utils.getPrice(stack) / stack.method_7947()) + "\"}]";

            boolean inserted = false;
            for (int i = 0; i < lore.size(); i++) {
                String line = class_3544.method_15440(lore.method_10608(i));
                if (line.contains("Цена: ")) {
                    lore.method_10531(i + 1, class_2519.method_23256(priceText));
                    inserted = true;
                    break;
                }
            }

            if (!inserted) {
                lore.add(class_2519.method_23256(priceText));
            }

            display.method_10566("Lore", lore);
            compound.method_10566("display", display);
            stack.method_7980(compound);
        }
    }

    @Override
    @SuppressWarnings("deprecation")
    public void method_25394(class_4587 matrices, int mouseX, int mouseY, float delta) {
        HistoryManager historyManager = HistoryManager.getInstance();
        super.method_25394(matrices, mouseX, mouseY, delta);

        fill(field_2797.field_7761);

        if (button == null) {
            button = new Button(new class_2585("Очистить"), new FloatRectangle(this.field_2776 - 150, this.field_2800 + this.field_2779 + 4, 145, 18), (btn) -> {
                historyManager.clear();
            }, Collections.singletonList(new class_2585("Нажмите чтобы очистить историю")));
        }

        if (this.field_22785.getString().contains("Поиск") || this.field_22785.getString().contains("Аукционы")) {
            if (afterInit.hasPasses(50)) {
                if (minPrice == null) minPrice = calculateMinPriceSlot();
            }
        }

        if (NeverAPI.isDevBuild()) {
            if (field_2787 != null) {
                class_1799 stack = field_2787.method_7677();
                CollectItem collectItem = SpookyBuy.getInstance().getAutoBuy().getItem(stack);

                if (collectItem != null) {
                    System.out.println(collectItem.getName());
                } else {
                    System.out.println(stack.method_7926(class_1304.field_6171).entries());
                }
            }
        }

        if (minPrice != null) {
            int i = this.field_2776;
            int j = this.field_2800;

            class_1735 slot = minPrice;

            RenderSystem.pushMatrix();
            RenderSystem.translatef((float) i, (float) j, 0.0F);
            RenderSystem.color4f(1.0F, 1.0F, 1.0F, 1.0F);
            RenderSystem.enableRescaleNormal();

            RenderSystem.glMultiTexCoord2f(33986, 240.0F, 240.0F);
            RenderSystem.color4f(1.0F, 1.0F, 1.0F, 1.0F);

            RenderSystem.disableDepthTest();
            int j1 = slot.field_7873;
            int k1 = slot.field_7872;

            RenderSystem.colorMask(true, true, true, false);
            this.method_25296(matrices, j1, k1, j1 + 16, k1 + 16, new Color(0x9907DF43, true).getRGB(), new Color(0x9907DF43, true).getRGB());
            RenderSystem.colorMask(true, true, true, true);
            RenderSystem.enableDepthTest();

            RenderSystem.popMatrix();
        }

        float offset = this.field_2800 + 16;
        float x = this.field_2776 - 148;

        Blur.register(() -> {
            Rounds.drawRound(this.field_2776 - 150, this.field_2800, 145, this.field_2779, 6, Color.BLACK);
        });

        Blur.draw(8, ColorUtility.getColorComps(new Color(0x717171)));

        String text = "История покупок";

        mc.field_1772.method_1729(matrices, text, x + (145 - mc.field_1772.method_1727(text)) / 2f, field_2800 + 3, -1);
        button.render(matrices);
        historyManager.render(matrices, x, offset, 145, this.field_2779);
    }

    @Override
    public void method_25420(class_4587 matrices) {

    }

    public class_1735 calculateMinPriceSlot() {
        class_1735 minPriceSlot = null;
        int minPrice = Integer.MAX_VALUE;

        for (int i = 0; i < this.method_17577().field_7761.size(); i++) {
            class_1735 slot = this.method_17577().method_7611(i);

            if (!slot.method_7677().method_7960()) {
                int price = Utils.getPrice(slot.method_7677());

                if (price == -1) continue;
                if (Utils.getSeller(slot.method_7677()).equalsIgnoreCase(mc.method_1548().method_1676())) continue;

                price = price / slot.method_7677().method_7947();

                CollectItem item = SpookyBuy.getInstance().getAutoBuy().getItem(slot.method_7677());

                if (item == null) continue;

                if (price < minPrice) {
                    minPrice = price;
                    minPriceSlot = slot;
                }
            }
        }

        return minPriceSlot;
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        this.button.mouseClicked(mouseX, mouseY, button);
        return super.method_25402(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double amount) {
        HistoryManager.getInstance().scroll += (float) (amount * 16);

        return super.method_25401(mouseX, mouseY, amount);
    }
}
