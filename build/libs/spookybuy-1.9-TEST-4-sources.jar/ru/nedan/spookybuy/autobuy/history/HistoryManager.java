package ru.nedan.spookybuy.autobuy.history;

import lombok.Getter;
import net.minecraft.class_1836;
import net.minecraft.class_241;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import ru.nedan.neverapi.gl.Scale;
import ru.nedan.neverapi.gl.Scissor;
import ru.nedan.neverapi.math.FloatRectangle;
import ru.nedan.neverapi.math.MathUtils;
import ru.nedan.neverapi.shader.Rounds;

import java.awt.*;
import java.util.ArrayList;
import java.util.concurrent.atomic.AtomicReference;

public class HistoryManager extends ArrayList<HistoryItem> {
    @Getter
    private static final HistoryManager instance;

    static {
        instance = new HistoryManager();
    }

    public float scroll, animatedScroll;
    class_310 mc = class_310.method_1551();

    public void render(class_4587 matrixStack, float x, float y, float width, float height) {
        Scissor.push();
        Scissor.setFromComponentCoordinates(x, y, width, height - 16);

        float offset = y + animatedScroll;
        float scissorBottom = y + height - 16;

        for (HistoryItem item : this) {
            float itemBottom = offset + 29;

            if (itemBottom >= y && offset <= scissorBottom) {
                renderItem(matrixStack, item, x, offset);
            }

            offset += 38;
        }

        Scissor.pop();

        AtomicReference<Float> offset1 = new AtomicReference<>(y + animatedScroll);

        assert mc.field_1755 != null;

        this.forEach(historyItem -> {
            if (MathUtils.isHovered(new FloatRectangle(x, offset1.get(), 140, 34))) {
                class_241 mousePos = MathUtils.getMousePos();
                mc.field_1755.method_25424(matrixStack, historyItem.getStack().getTooltip(mc.field_1724, class_1836.class_1837.field_8934), (int) mousePos.field_1343, (int) mousePos.field_1342);
            }

            offset1.updateAndGet(v -> v + 38);
        });

        animatedScroll = MathUtils.lerp(animatedScroll, scroll, 8);
        scroll = class_3532.method_15363(scroll, -(size() * 40 + 10), 0);
    }

    private void renderItem(class_4587 matrixStack, HistoryItem item, float x, float y) {
        Rounds.drawRound(x, y, 140, 34, 4, new Color(0x1C1C1C));

        // RENDER ITEM

        Scale.renderScaled(() -> {
            mc.method_1480().method_4010(item.getStack(), (int) (x + 8), (int) (y + 7));
            mc.method_1480().method_4025(mc.field_1772, item.getStack(),  (int) (x + 8), (int) (y + 7));
        }, new FloatRectangle(x + 8, y + 8, 25, 25), 1.35f);

        mc.field_1772.method_1729(matrixStack, item.getCollectItem().getName(), x + 30, y + 4, -1);
        mc.field_1772.method_1729(matrixStack, item.getStatus().getStatusText(), x + 30, y + 14, -1);
        mc.field_1772.method_1729(matrixStack, "Время: " + item.getDate(), x + 30, y + 24, -1);
    }
}
