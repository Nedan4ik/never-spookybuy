package ru.nedan.spookybuy.autobuy.functional.inst;

import lombok.Getter;
import lombok.Setter;
import net.minecraft.class_124;
import net.minecraft.class_1707;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2813;
import net.minecraft.class_2868;
import net.minecraft.class_310;
import net.minecraft.class_3544;
import net.minecraft.class_476;
import ru.nedan.neverapi.NeverAPI;
import ru.nedan.neverapi.etc.ChatUtility;
import ru.nedan.neverapi.etc.TextBuilder;
import ru.nedan.neverapi.event.impl.EventInput;
import ru.nedan.neverapi.event.impl.EventMessage;
import ru.nedan.neverapi.event.impl.EventPlayerTick;
import ru.nedan.neverapi.math.TimerUtility;
import ru.nedan.spookybuy.SpookyBuy;
import ru.nedan.spookybuy.autobuy.AutoBuy;
import ru.nedan.spookybuy.autobuy.GenericContainerScreenHook;
import ru.nedan.spookybuy.autobuy.autoparse.AutoParser;
import ru.nedan.spookybuy.autobuy.functional.ABInputListener;
import ru.nedan.spookybuy.autobuy.functional.ABMessageListener;
import ru.nedan.spookybuy.autobuy.functional.ABTicker;
import ru.nedan.spookybuy.autobuy.history.HistoryItem;
import ru.nedan.spookybuy.autobuy.history.HistoryManager;
import ru.nedan.spookybuy.event.EventPreSell;
import ru.nedan.spookybuy.event.EventStartResell;
import ru.nedan.spookybuy.event.EventStopResell;
import ru.nedan.spookybuy.items.CollectItem;
import ru.nedan.spookybuy.items.ItemStorage;
import ru.nedan.spookybuy.util.Utils;
import ru.nedan.spookybuy.util.telegram.TelegramAPI;

import java.math.BigDecimal;
import java.util.Map;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@SuppressWarnings("UnstableApiUsage")
public class AutoBuyFunction implements ABTicker, ABMessageListener, ABInputListener {
    private final AutoBuy autoBuy;
    private static final class_310 mc = class_310.method_1551();
    final Map<String, Boolean> flags;
    final Map<String, TimerUtility> timers;

    public AutoBuyFunction(AutoBuy autoBuy, Map<String, Boolean> flags, Map<String, TimerUtility> timers) {
        this.flags = flags;
        this.timers = timers;
        this.autoBuy = autoBuy;
    }

    // STATS
    @Getter
    private BigDecimal sell = BigDecimal.ZERO, buy = BigDecimal.ZERO;

    @Setter
    @Getter
    private boolean sendBuy = true, sendSell = true;

    class_1799 activeStack;
    CollectItem activeCollect;

    private final Pattern sellPattern = Pattern.compile("^\\[☃] У Вас купили (.+) за \\$([\\d,]+) на /ah$");
    private final Pattern buyPattern = Pattern.compile("^\\[☃] Вы успешно купили (.+) за \\$([\\d,]+)!$");


    // Переменные для рандомизации update задержки
    private final Random random = new Random();
    private static final int UPDATE_MIN_DELAY = 250; // минимальная задержка 250 мс
    private static final int UPDATE_MAX_DELAY = 300; // максимальная задержка 450 мс
    private int currentUpdateDelay = UPDATE_MIN_DELAY;

    // Таймер для проверки gray_dye
    private final TimerUtility grayDyeCheckTimer = new TimerUtility();
    private static int GRAY_DYE_CHECK_INTERVAL = 1000; // Проверка каждую секунду
    private static int GRAY_DYE_LIMIT = 2; // Лимит gray_dye в слотах

    @Override
    public void tick(EventPlayerTick e) {
        if (AutoParser.getInstance().tick()) return;

        if (!SpookyBuy.getInstance().isState()) return;

        assert mc.field_1761 != null;
        assert mc.field_1724 != null;



        if (mc.field_1755 instanceof class_476 screen) {
            class_1707 screenHandler = screen.method_17577();
            int sId = screenHandler.field_7763;

            // Проверяем наличие gray_dye в слотах
            if (grayDyeCheckTimer.hasPasses(GRAY_DYE_CHECK_INTERVAL)) {
                int grayDyeCount = countGrayDye(screenHandler);
                if (grayDyeCount > GRAY_DYE_LIMIT) {
                    // Закрываем сундук
                    mc.field_1724.method_7346();

                    TextBuilder textBuilder = SpookyBuy.getSpookyBuyAppender().copy()
                            .append("Обнаружено более " + GRAY_DYE_LIMIT + " не актуальных предметов. Обход найден by Zr3");
                    ChatUtility.sendMessage(textBuilder.build());

                    grayDyeCheckTimer.updateLast();
                    return;
                }
                grayDyeCheckTimer.updateLast();
            }

            if (flags.get("resell")) {
                if (timers.get("ab.resellItem").hasPasses(400)) {
                    if (!class_3544.method_15440(screen.method_25440().getString()).contains("Хранилище")) {
                        clickSilent(sId, 46);
                    } else {
                        class_1799 stack = screenHandler.method_7611(0).method_7677();

                        if (stack.method_7960()) {
                            flags.replace("resell", false);
                            flags.replace("autoSell", true);
                            timers.get("autosell.open").updateLast();
                            timers.get("autosell.sell").updateLast();
                            mc.field_1724.method_7346();

                            NeverAPI.getApi().getEventBus().post(new EventStopResell());
                        } else {
                            clickSilent(sId, 0);
                        }
                    }

                    timers.get("ab.resellItem").updateLast();
                }

                return;
            }

            if (timers.get("ab.resell").hasPasses(90000)) {
                EventStartResell eventStartResell = new EventStartResell();
                NeverAPI.getApi().getEventBus().post(eventStartResell);

                if (!eventStartResell.isCanceled()) {
                    flags.replace("resell", true);
                    timers.get("ab.resell").updateLast();
                }
            }

            // Рандомизированная задержка для update
            if (timers.get("ab.update").hasPasses(currentUpdateDelay)) {
                clickSilent(sId, 49);
                timers.get("ab.update").updateLast();

                // Генерируем новую случайную задержку для следующего раза
                randomizeUpdateDelay();
            }

            long time = SpookyBuy.getInstance().getAutoSetupTime();

            if (time >= 300000) {
                if (timers.get("autosetup.enable").hasPasses(time)) {
                    SpookyBuy.getInstance().setAutoSetupState(true);
                    mc.field_1724.method_7346();
                    onAutoSetupToggle(true);
                    AutoParser.getInstance().hasAutoBuyState = true;
                    timers.get("autosetup.enable").updateLast();
                }
            }

            TimerUtility buyTimer = timers.get("ab.buy");
            if (!buyTimer.hasPasses(100)) return;

            for (class_1735 slot : screenHandler.field_7761) {
                class_1799 stack = slot.method_7677();

                if (stack.method_7960()) continue;

                int totalPrice = Utils.getPrice(stack);
                if (totalPrice <= 0) continue;

                if (totalPrice > autoBuy.balance.intValue()) continue;

                int count = stack.method_7947();
                int stackPrice = totalPrice / count;

                CollectItem collectItem = null;
                for (CollectItem item : ItemStorage.ALL) {
                    if (CollectItem.CHECKER.test(stack, item)) {
                        collectItem = item;
                        break;
                    }
                }

                if (collectItem == null) continue;

                BigDecimal limitPrice = autoBuy.getPriceMap().getPrice(collectItem, false);
                if (limitPrice == null) continue;

                if (limitPrice.compareTo(BigDecimal.valueOf(stackPrice)) < 0) continue;

                buyTimer.updateLast();
                timers.get("ab.update").updateLast();

                activeStack = stack.method_7972();
                activeCollect = collectItem;

                mc.field_1761.method_2906(
                        sId,
                        slot.field_7874,
                        0,
                        class_1713.field_7794,
                        mc.field_1724
                );

                break;
            }
        } else {
            if (timers.get("autosell.open").hasPasses(2500)) {
                mc.field_1724.method_3142("/ah");
                timers.get("autosell.open").updateLast();
            }

            if (!flags.get("autoSell")) return;

            if (timers.get("autosell.sell").hasPasses(1000)) {
                for (int i = 0; i <= 36; ++i) {
                    if (i == 36) {
                        flags.replace("autoSell", false);
                        return;
                    }

                    class_1799 stack = mc.field_1724.field_7514.method_5438(i);
                    if (stack.method_7960()) continue;
                    CollectItem collectItem = autoBuy.getItem(stack);
                    if (collectItem == null) continue;
                    boolean isPhantom = Utils.getPrice(stack) != -1;
                    if (isPhantom) continue;

                    timers.get("autosell.sell").updateLast();
                    timers.get("autosell.open").updateLast();

                    BigDecimal sellPrice = autoBuy.getPriceMap().getPrice(collectItem, true);
                    int price = sellPrice.intValue() * stack.method_7947();

                    int maxSellPrice = collectItem.getMaxSellPrice();

                    if (price > maxSellPrice) continue;

                    if (i < 9) {
                        mc.field_1724.field_7514.field_7545 = i;
                        mc.field_1724.field_3944.method_2883(new class_2868(i));

                        EventPreSell eventPreSell = new EventPreSell(collectItem);
                        NeverAPI.getApi().getEventBus().post(eventPreSell);
                        if (eventPreSell.isCanceled()) continue;

                        mc.field_1724.method_3142("/ah sell " + price);
                    } else {
                        mc.field_1761.method_2916(i);

                        EventPreSell eventPreSell = new EventPreSell(collectItem);
                        NeverAPI.getApi().getEventBus().post(eventPreSell);
                        if (eventPreSell.isCanceled()) continue;

                        mc.field_1724.method_3142("/ah sell " + price);
                    }

                    break;
                }
            }
        }
    }

    /**
     * Подсчитывает количество gray_dye в слотах сундука
     * @param screenHandler обработчик экрана сундука
     * @return количество gray_dye
     */
    private int countGrayDye(class_1707 screenHandler) {
        int count = 0;
        for (class_1735 slot : screenHandler.field_7761) {
            class_1799 stack = slot.method_7677();
            if (!stack.method_7960() && stack.method_7909() == class_1802.field_8298) {
                count += stack.method_7947();
            }
        }
        return count;
    }

    /**
     * Рандомизирует задержку для update между минимальным и максимальным значениями
     */
    private void randomizeUpdateDelay() {
        currentUpdateDelay = UPDATE_MIN_DELAY + random.nextInt(UPDATE_MAX_DELAY - UPDATE_MIN_DELAY + 1);
    }

    /**
     * Устанавливает диапазон рандомизации для update задержки
     * @param min минимальная задержка в миллисекундах
     * @param max максимальная задержка в миллисекундах
     */
    public void setUpdateDelayRange(int min, int max) {
        if (min > max) {
            throw new IllegalArgumentException("Min delay cannot be greater than max delay");
        }
        currentUpdateDelay = min + random.nextInt(max - min + 1);
    }

    /**
     * Устанавливает лимит gray_dye для автоматического закрытия сундука
     * @param limit новое значение лимита
     */
    public void setGrayDyeLimit(int limit) {
        GRAY_DYE_LIMIT = limit;
    }

    /**
     * Устанавливает интервал проверки gray_dye
     * @param interval интервал в миллисекундах
     */
    public void setGrayDyeCheckInterval(int interval) {
        GRAY_DYE_CHECK_INTERVAL = interval;
    }

    @Override
    public void message(EventMessage e) {
        String mes = e.getMessage();
        assert mc.field_1724 != null;

        if (!e.isSend()) {
            if (class_3544.method_15440(mes).matches("\\[☃\\] Не удалось выставить .+, освободите хранилище или арендуйте больше слотов на /ah rent!")) {
                flags.replace("autoSell", false);
                return;
            }

            // AFK сообщения больше не вызывают переподключение
            if (mes.equalsIgnoreCase("Данная команда недоступна в режиме AFK") ||
                    mes.equalsIgnoreCase("Недопустимо нажимать в режиме AFK")) {
                // Просто игнорируем, ничего не делаем
                return;
            }

            Matcher sellMatcher = sellPattern.matcher(mes);
            if (sellMatcher.matches()) {
                String item = sellMatcher.group(1);
                String price = sellMatcher.group(2);

                if (sendSell)
                    TelegramAPI.sendMessage(String.format("У вас купили %s за $%s", item, price), null);

                sell = sell.add(new BigDecimal(price.replaceAll("[^\\d.]", "")));
                return;
            }

            if (activeStack == null || activeCollect == null) return;

            if (mes.equalsIgnoreCase("[☃] Этот товар уже купили!")) {
                if (sendBuy)
                    TelegramAPI.sendMessage(
                            String.format("Не удалось купить %s (%s) у игрока %s. Причина: Товар уже купили.",
                                    activeStack.method_7964().getString(),
                                    activeCollect.getName(),
                                    Utils.getSeller(activeStack)
                            ),
                            null
                    );

                addHistoryItem(HistoryItem.Status.NOTBUY);
                activeStack = null;
                return;
            }

            if (mes.equalsIgnoreCase("[☃] У Вас не хватает денег!")) {
                if (sendBuy)
                    TelegramAPI.sendMessage(
                            String.format("Не удалось купить %s (%s) у игрока %s. Причина: У вас не хватает денег.",
                                    activeStack.method_7964().getString(),
                                    activeCollect.getName(),
                                    Utils.getSeller(activeStack)
                            ),
                            null
                    );

                addHistoryItem(HistoryItem.Status.NOTBUY);

                activeStack = null;
                return;
            }

            Matcher buyMatcher = buyPattern.matcher(mes);
            if (buyMatcher.matches()) {
                String item = buyMatcher.group(1);
                String price = buyMatcher.group(2);

                String seller = Utils.getSeller(activeStack);
                String displayName = activeCollect.getName();

                if (sendBuy)
                    TelegramAPI.sendMessage(
                            String.format("Вы успешно купили %s (%s x%s) у %s за $%s", item, displayName, activeStack.method_7947(), seller, price),
                            null
                    );

                buy = buy.add(new BigDecimal(price.replaceAll("[^\\d.]", "")));

                addHistoryItem(HistoryItem.Status.BUY);
                activeStack = null;
            }
        }
    }

    // ANTI AFK
    private final TimerUtility notifyTimer = new TimerUtility();

    @Override
    public void input(EventInput e) {
        if (SpookyBuy.getInstance().isState()) {
            if (e.getMovementForward() != 0 || e.getMovementSideways() != 0 || e.isJumping() || e.isSneaking()) {
                if (notifyTimer.hasPasses(3000)) {
                    TextBuilder textBuilder = SpookyBuy.getSpookyBuyAppender().copy()
                            .append("Автобай активен - движение заблокировано");

                    ChatUtility.sendMessage(textBuilder.build());

                    notifyTimer.updateLast();
                }
            }

            e.setMovementForward(0.0F);
            e.setMovementSideways(0.0F);
            e.setJumping(false);
            e.setSneaking(false);
        }
    }


    private void clickSilent(int containerId, int slot) {
        assert mc.field_1724 != null;
        short short1 = mc.field_1724.field_7512.method_7614(mc.field_1724.field_7514);
        mc.field_1724.field_3944.method_2883(new class_2813(containerId, slot, 0, class_1713.field_7790, class_1799.field_8037, short1));
    }

    public static void onAutoSetupToggle(boolean autoBuy) {
        ChatUtility.sendMessage(new TextBuilder()
                .append("АвтоСетап успешно ")
                .append(SpookyBuy.getInstance().isAutoSetupState() ? "запущен!" : "выключен!", SpookyBuy.getInstance().isAutoSetupState() ? class_124.field_1060 : class_124.field_1061)
                .build());

        if (autoBuy) SpookyBuy.getInstance().setState(false);

        AutoParser.getInstance().added.clear();
    }

    private void addHistoryItem(HistoryItem.Status status) {
        HistoryItem historyItem = HistoryItem.of(activeStack, activeCollect, status);
        HistoryManager.getInstance().add(historyItem);

        if (mc.field_1755 instanceof GenericContainerScreenHook) {
            HistoryManager.getInstance().scroll -= 38;
        }
    }
}