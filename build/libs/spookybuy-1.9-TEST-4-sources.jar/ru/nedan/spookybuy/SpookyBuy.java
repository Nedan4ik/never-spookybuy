package ru.nedan.spookybuy;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import lombok.Getter;
import lombok.Setter;
import net.fabricmc.api.ModInitializer;
import net.minecraft.class_124;
import net.minecraft.class_156;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2519;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_2585;
import net.minecraft.class_310;
import net.minecraft.class_3545;
import net.minecraft.class_476;
import net.minecraft.class_5251;
import org.lwjgl.glfw.GLFW;
import ru.nedan.neverapi.NeverAPI;
import ru.nedan.neverapi.etc.*;
import ru.nedan.neverapi.event.api.Event;
import ru.nedan.neverapi.event.impl.EventPress;
import ru.nedan.neverapi.event.impl.EventWindowOpen;
import ru.nedan.neverapi.shader.ColorUtility;
import ru.nedan.spookybuy.autobuy.AutoBuy;
import ru.nedan.spookybuy.autobuy.GenericContainerScreenHook;
import ru.nedan.spookybuy.autobuy.autoparse.AutoParser;
import ru.nedan.spookybuy.autobuy.autoparse.coefficient.Coefficient;
import ru.nedan.spookybuy.autobuy.functional.inst.AutoBuyFunction;
import ru.nedan.spookybuy.screen.configs.ConfigScreen;
import ru.nedan.spookybuy.screen.setting.SpookyBuyGui;
import ru.nedan.spookybuy.util.script.ScriptStorage;
import ru.nedan.spookybuy.util.CommandRegister;
import ru.nedan.spookybuy.util.Discord;
import ru.nedan.spookybuy.util.autojoin.AutoJoin;
import ru.nedan.spookybuy.util.autojoin.AutoJoinConfiguration;
import ru.nedan.spookybuy.util.telegram.TelegramAPI;
import ru.nedan.spookybuy.util.telegram.command.api.TelegramCommandExecutor;
import ru.nedan.spookybuy.util.ws.Client;

import java.awt.*;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Getter
public class SpookyBuy implements ModInitializer {
    @Getter
    private static SpookyBuy instance;

    private static final class_310 mc = class_310.method_1551();

    @Setter
    private boolean state, autoSetupState;

    @Setter
    private long autoSetupTime;

    private final SpookyBuyGui gui = new SpookyBuyGui();
    private final AutoBuy autoBuy;
    private final TelegramCommandExecutor commandExecutor;

    @Setter
    private int abKey;

    @Setter
    private int autoSetupKey;

    @Getter
    private static final TextBuilder spookyBuyAppender = new TextBuilder()
            .append(gradient())
            .append(" » ", class_124.field_1078);

    private final Executor executor = Executors.newCachedThreadPool();

    @Setter
    private String anarchy;

    @Override
    public void onInitialize() {
    }

    private final Discord discordRPC;

    public SpookyBuy() {
        if (!NeverAPI.isInit()) new NeverAPI();

        instance = this;
        autoBuy = new AutoBuy();
        commandExecutor = new TelegramCommandExecutor();

        TelegramAPI.start();
        CommandRegister.registerAll();
        new AutoParser();
        new AutoJoin();
        new Client("ws://5.83.140.208:25975").startClient();

        discordRPC = new Discord();
        discordRPC.run();

        TextVisitors.putConsumer((string, reference) -> {
            if (string.contains(mc.method_1548().method_1676())) {
                reference.set(string.replaceAll(mc.method_1548().method_1676(), "t.me/neverproduct"));
            }
        });

        Pattern donatePattern = Pattern.compile("\\b(Игрок|Барон|Страж|Герой|Глава|Аспид|Сквид|Элита|Титан|Принц|Князь|Герцог)\\b");

        TextVisitors.putConsumer(((string, style, reference) -> {
            Matcher matcher = donatePattern.matcher(string);

            /* замена любого доната на Staff
            if (matcher.find()) {
                String foundDonate = matcher.group(1);
                reference.set(new Pair<>(string.replaceAll(foundDonate, "Staff"), style.withFormatting(Formatting.RED)));
            }*/

            if (string.contains(mc.method_1548().method_1676())) {
                reference.set(new class_3545<>(string.replaceAll(mc.method_1548().method_1676(), "t.me/neverproduct"), reference.get().method_15441()));
            }
        }));

        Event.addListener(EventWindowOpen.class, e -> {
            if (e.getScreen() instanceof class_476) {
                e.setScreen(new GenericContainerScreenHook((class_476) e.getScreen()));
            }
        });

        Event.addListener(EventPress.class, e -> {
            if (e.getAction() == 1) {
                if (mc.field_1755 == null || mc.field_1755 instanceof class_476) {
                    if (e.getKey() == abKey) {
                        state = !state;
                        ChatUtility.sendMessage(spookyBuyAppender
                                .copy()
                                .append("АвтоБай успешно ")
                                .append(state ? "включен!" : "выключен!", state ? class_124.field_1060 : class_124.field_1061)
                                .build());
                    }

                    if (e.getKey() == autoSetupKey) {
                        autoSetupState = !autoSetupState;
                        AutoBuyFunction.onAutoSetupToggle(false);
                    }

                    if (e.getKey() == GLFW.GLFW_KEY_G) {
                        assert mc.field_1724 != null;
                        ConfigScreen sc = new ConfigScreen(mc.field_1724.field_7514, (slot, button) -> {
                            if (slot == -999) return;

                            ConfigScreen configScreen = (ConfigScreen) mc.field_1755;

                            assert configScreen != null;
                            class_1799 stack = configScreen.method_17577().method_7611(slot).method_7677();

                            if (stack.method_7960()) return;
                            class_2487 compound = stack.method_7969();

                            assert compound != null;

                            if (button == 0) {
                                String key = compound.method_10558("key");
                                String cloudKey = configScreen.keys.get(key);
                                Client.getInstance().sendLoadConfigResponse(cloudKey);
                            } else if (button == 1) {
                                class_156.method_668().method_670(compound.method_10558("discordLink"));
                            } else if (button == 2) {
                                String itemName = compound.method_10558("authorName");
                                ConfigScreen.toggleAuthor(itemName);

                                class_2487 display = compound.method_10562("display");

                                class_2499 lore = display.method_10554("Lore", 8);

                                if (!lore.isEmpty()) {
                                    class_2583 defaultStyle = class_2583.field_24360.method_10978(false);
                                    class_2583 actionStyle = defaultStyle.method_10977(class_124.field_1065);

                                    lore.method_10606(3, class_2519.method_23256(class_2561.class_2562.method_10867(new class_2585("СКМ Авто-загрузка: ").method_10862(actionStyle).method_10852(new class_2585(ConfigScreen.autoInject(itemName) ? "§aвключено" : "§cвыключено")))));
                                }

                                display.method_10566("Lore", lore);
                                compound.method_10566("display", display);
                                stack.method_7980(compound);
                            }
                        });

                        mc.method_1507(sc);
                        mc.field_1724.field_7512 = sc.method_17577();
                    }
                }

                if (mc.field_1755 != null) return;

                if (e.getKey() == GLFW.GLFW_KEY_RIGHT_SHIFT) {
                    mc.method_1507(gui);
                }
            }
        });

        {
/*            JsonElement element = Config.readData("./config/default-spookybuy.nvr");

            if (element != null) {
                loadConfig(element);
            }*/

            JsonElement telegramElement = Config.readData("./config/telegram-spookybuy.nvr");

            if (telegramElement != null) {
                TelegramAPI.readFromConfig(telegramElement);
            }

            AutoJoinConfiguration.deserialize();
        }

        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
//            saveConfig("default-spookybuy");
            saveTelegram();
            AutoJoinConfiguration.serialize();
        }));

        if (!Libraries.hasLibrary("org.openjdk.nashorn.api.scripting.ScriptUtils")) {
            try {
                Libraries.setToDownload("https://repo1.maven.org/maven2/", "org.openjdk.nashorn", "nashorn-core", "15.6");
            } catch (Exception e) {
                e.printStackTrace(System.err);
            }
        }

        try {
            ScriptStorage.reloadScripts();
        } catch (Exception e) {
            e.printStackTrace(System.err);
        }
    }

    public static void saveConfig(String file) {
        Config.saveData("./config/" + file + ".nvr", saveConfig());
    }

    public static JsonObject saveConfig() {
        JsonObject mai = new JsonObject();
        JsonObject main = new JsonObject();
        JsonObject settings = new JsonObject();

        settings.addProperty("abBind", instance.abKey);
        settings.addProperty("autoSetupBind", instance.autoSetupKey);

        main.add("settings", settings);

        JsonObject items = new JsonObject();
        instance.getAutoBuy().getPriceMap().saveInConfig(items);

        main.add("items", items);

        JsonArray coefficients = new JsonArray();
        for (Coefficient coefficient : Coefficient.getAll()) coefficient.serialize(coefficients);

        main.add("coefficients", coefficients);

        mai.add("main", main);

        return mai;
    }

    private void saveTelegram() {
        String path = "./config/telegram-spookybuy.nvr";
        JsonObject main = new JsonObject();

        TelegramAPI.saveInConfig(main);

        Config.saveData(path, main);
    }

    public static void loadConfig(JsonElement element) {
        if (!element.isJsonObject()) return;

        JsonObject mai = element.getAsJsonObject();

        if (!mai.has("main")) return;

        JsonObject main = mai.getAsJsonObject("main");

        if (main.has("settings")) {
            JsonObject settings = main.getAsJsonObject("settings");

            if (settings.has("abBind")) {
                instance.abKey = settings.get("abBind").getAsInt();
            }

            if (settings.has("autoSetupBind")) {
                instance.autoSetupKey = settings.get("autoSetupBind").getAsInt();
            }
        }

        if (main.has("items")) {
            instance.getAutoBuy().getPriceMap().readFromConfig(main);
        }

        if (main.has("coefficients")) {
            Coefficient.deserialize(main.getAsJsonArray("coefficients"));
        }
    }

    private static class_2585 gradient() {
        int first = new Color(0x4344D6).getRGB();
        int end = new Color(0x0642C6).getRGB();

        class_2585 text = new class_2585("");
        for (int i = 0; i < "Never SpookyBuy".length(); i++)
            text.method_10852(new class_2585(String.valueOf("Never SpookyBuy".charAt(i))).method_10862(class_2583.field_24360.method_27703(class_5251.method_27717(ColorUtility.interpolateColor(first, end, (float) i / "NeverBuy".length())))));

        text.method_10852(new class_2585("").method_27692(class_124.field_1070));

        return text;
    }
}
