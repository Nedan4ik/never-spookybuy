package ru.nedan.spookybuy.screen.setting;

import net.minecraft.class_2585;
import net.minecraft.class_437;
import net.minecraft.class_4587;
import ru.nedan.neverapi.math.FloatRectangle;
import ru.nedan.neverapi.math.MathUtils;
import ru.nedan.spookybuy.screen.setting.page.Page;
import ru.nedan.spookybuy.screen.setting.page.Pages;
import ru.nedan.spookybuy.screen.setting.page.icon.IconRenderer;
import ru.nedan.spookybuy.screen.setting.page.inst.ItemsPage;

public class SpookyBuyGui extends class_437 {

    public SpookyBuyGui() {
        super(new class_2585("SpookyBuyGui"));
    }

    @Override
    protected void method_25426() {
        super.method_25426();

        float width = (float) Pages.ALL.stream()
                .map(Page::getIconRenderer)
                .map(IconRenderer::getTitle)
                .mapToInt(title -> client.textRenderer.getWidth(title) + 10)
                .sum();

        float height = 20;

        FloatRectangle iconPositions = MathUtils.getCenteredPosition(width, height).offset(0, 200);

        for (Page page : Pages.ALL) {
            page.getIconRenderer().updatePosition(new FloatRectangle(iconPositions.x, iconPositions.y, field_22787.field_1772.method_1727(page.getIconRenderer().getTitle()) + 5, 13));
            iconPositions = iconPositions.offset(field_22787.field_1772.method_1727(page.getIconRenderer().getTitle()) + 10, 0);
        }

        Pages.init();
    }

    @Override
    public void method_25394(class_4587 matrices, int mouseX, int mouseY, float delta) {
        this.method_25420(matrices);

        Pages.render(matrices);

        for (Page page : Pages.ALL) {
            page.getIconRenderer().render(matrices);
        }

        super.method_25394(matrices, mouseX, mouseY, delta);
    }

    @Override
    public void method_16014(double mouseX, double mouseY) {
        super.method_16014(mouseX, mouseY);
    }

    @Override
    public boolean method_25406(double mouseX, double mouseY, int button) {
        Pages.mouseReleased(button);

        return super.method_25406(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        Pages.mouseClicked(button);

        for (Page page : Pages.ALL) {
            page.getIconRenderer().mouseClicked(button);
        }

        return super.method_25402(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25400(char chr, int modifiers) {
        Pages.charTyped(chr);

        return super.method_25400(chr, modifiers);
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        Pages.keyPressed(keyCode);

        return super.method_25404(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double amount) {
        Pages.mouseScrolled(amount);

        return super.method_25401(mouseX, mouseY, amount);
    }
}
