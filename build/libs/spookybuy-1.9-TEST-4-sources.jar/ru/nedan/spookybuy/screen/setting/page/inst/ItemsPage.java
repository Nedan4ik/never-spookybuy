package ru.nedan.spookybuy.screen.setting.page.inst;

import ru.nedan.neverapi.animation.util.Easings;
import ru.nedan.neverapi.etc.KeyUtil;
import ru.nedan.neverapi.etc.TextBuilder;
import ru.nedan.neverapi.gl.Scale;
import ru.nedan.neverapi.gl.Scissor;
import ru.nedan.neverapi.gui.Button;
import ru.nedan.neverapi.gui.TextField;
import ru.nedan.neverapi.math.FloatRectangle;
import ru.nedan.neverapi.math.MathUtils;
import ru.nedan.neverapi.shader.Blur;
import ru.nedan.neverapi.shader.ColorUtility;
import ru.nedan.neverapi.shader.Rounds;
import ru.nedan.spookybuy.SpookyBuy;
import ru.nedan.spookybuy.items.CollectItem;
import ru.nedan.spookybuy.items.ItemStorage;
import ru.nedan.spookybuy.screen.setting.ItemRenderer;
import ru.nedan.spookybuy.screen.setting.allocation.Allocation;
import ru.nedan.spookybuy.screen.setting.page.Page;
import ru.nedan.spookybuy.screen.setting.page.Pages;
import ru.nedan.spookybuy.screen.setting.page.icon.IconRenderer;

import java.awt.*;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import net.minecraft.class_124;
import net.minecraft.class_241;
import net.minecraft.class_2561;
import net.minecraft.class_2585;
import net.minecraft.class_3532;
import net.minecraft.class_437;
import net.minecraft.class_4587;

public class ItemsPage extends Page {

    private static ItemsPage instance;

    private FloatRectangle positions, original;
    private List<ItemRenderer> renderers;
    private Button abBindButton, autoSetupBindButton, timedAutoSetup;

    private boolean abBinding, autoSetupBinding;

    private TextField buyPriceField, sellPrice;

    public ItemsPage() {
        instance = this;
    }

    public static Page getInstance() {
        if (instance == null) new ItemsPage();

        return instance;
    }

    @Override
    public void init() {
        float width = 200;
        float height = 220;

        positions = MathUtils.getCenteredPosition(width, height);
        original = MathUtils.getCenteredPosition(width, height);
        renderers = new ArrayList<>();

        float offset = 22;

        for (CollectItem collectItem : ItemStorage.ALL) {
            ItemRenderer itemRenderer = new ItemRenderer(new FloatRectangle(positions.x + 3, positions.y, positions.width - 6, 18), collectItem, offset);
            renderers.add(itemRenderer);
            offset += itemRenderer.getPosition().height + 3;
        }

        abBindButton = new ru.nedan.neverapi.gui.Button(class_2561.method_30163("Автобай: " + KeyUtil.getKey(SpookyBuy.getInstance().getAbKey())), new FloatRectangle(positions.x, positions.y + positions.height + 4, positions.width, 16), (button) -> {
            abBinding = true;
            button.setTitle(Text.of("Клик..."));
        }, Collections.singletonList(class_2561.method_30163("Клик чтобы забиндить автобай")));

        autoSetupBindButton = new Button(class_2561.method_30163("АвтоСетап: " + KeyUtil.getKey(SpookyBuy.getInstance().getAutoSetupKey())), new FloatRectangle(positions.x, positions.y + positions.height + 24, positions.width, 16), (button) -> {
            autoSetupBinding = true;
            button.setTitle(Text.of("Клик..."));
        }, Collections.singletonList(class_2561.method_30163("Клик чтобы забиндить автосетап")));

        timedAutoSetup = new Button(class_2561.method_30163("Время автонастройки: " + SpookyBuy.getInstance().getAutoSetupTime()), new FloatRectangle(positions.x, positions.y + positions.height + 44, positions.width, 16), (button) -> {

        }, Arrays.asList(class_2561.method_30163("Миллисекунды"), new TextBuilder().append("Со значением ").append("менее", class_124.field_1061).append(" 300000").append(" не работает", class_124.field_1061).build(), class_2561.method_30163("ЛКМ - увеличить на 1000 (c CTRL на 10000)"), class_2561.method_30163("ПКМ - уменьшить на 1000 (c CTRL на 10000)"))) {
            @Override
            public void mouseClicked(double mouseX, double mouseY, int button) {
                if (this.getPositions().contains(mouseX, mouseY)) {
                    long time = SpookyBuy.getInstance().getAutoSetupTime();
                    boolean hasCtrl = class_437.method_25441();

                    switch (button) {
                        case 0: {
                            // INCREASE
                            SpookyBuy.getInstance().setAutoSetupTime(time + (hasCtrl ? 10000 : 1000));
                            this.setTitle(class_2561.method_30163("Время автонастройки: " + SpookyBuy.getInstance().getAutoSetupTime()));
                            break;
                        }
                        case 1: {
                            long decrement = hasCtrl ? 10000 : 1000;

                            if (time <= 0) break;

                            long newTime = Math.max(0, time - decrement);

                            SpookyBuy.getInstance().setAutoSetupTime(newTime);
                            this.setTitle(class_2561.method_30163("Время автонастройки: " + newTime));
                            break;
                        }

                        default:
                            break;
                    }
                }
            }
        };

        FloatRectangle position = new FloatRectangle(this.positions.x + this.positions.width + 30, this.positions.y, 180, 120);

        buyPriceField = new ru.nedan.neverapi.gui.TextField(position.x + 3, position.y + 20, position.width - 6, 12, "Цена покупки всех предметов", (string) -> {
            if (string.isEmpty()) string = "0";

            BigDecimal bigDecimal = new BigDecimal(string);

            List<ItemRenderer> allocatedRenderers = renderers.stream()
                    .filter(itemRenderer1 -> itemRenderer1.allocated)
                    .toList();

            for (ItemRenderer renderer : allocatedRenderers) {
                SpookyBuy.getInstance().getAutoBuy().getPriceMap().putPrice(renderer.getCollectItem(), bigDecimal, false);
//                SpookyBuy.getInstance().getAutoBuy().getPriceMap().putCoefficient(renderer.getCollectItem(), bigDecimal, true);
            }

//            SpookyBuy.getInstance().getAutoBuy().getPriceMap().putPrice(collectItem, bigDecimal, false);
        }, Character::isDigit);

        sellPrice = new ru.nedan.neverapi.gui.TextField(position.x + 3, position.y + 38, position.width - 6, 12, "Цена продажи всех предметов", (string) -> {
            if (string.isEmpty()) string = "0";

            BigDecimal bigDecimal = new BigDecimal(string);

            List<ItemRenderer> allocatedRenderers = renderers.stream()
                    .filter(itemRenderer1 -> itemRenderer1.allocated)
                    .toList();

            for (ItemRenderer renderer : allocatedRenderers) {
                SpookyBuy.getInstance().getAutoBuy().getPriceMap().putPrice(renderer.getCollectItem(), bigDecimal, true);
            }
        }, Character::isDigit);
    }

    public float scroll, animatedScroll;

    @Override
    public void render(class_4587 matrixStack) {
        translateAnimation.update();
        positions = original.offset((float) translateAnimation.getValue(), 0);

        abBindButton.updatePositions(positions.x, positions.y + positions.height + 4, positions.width, 16);
        autoSetupBindButton.updatePositions(positions.x, positions.y + positions.height + 24, positions.width, 16);
        timedAutoSetup.updatePositions(positions.x, positions.y + positions.height + 44, positions.width, 16);

        Blur.register(() -> Rounds.drawRound(positions.x, positions.y, positions.width, positions.height, 8, Color.BLACK));
        Blur.draw(4, ColorUtility.getColorComps(new Color(0x717171)));

        class_2561 text = class_2561.method_30163("Never SpookyBuy");
        class_241 textPos = MathUtils.getCenteredTextPosition(text, new FloatRectangle(positions.x, positions.y + 4, positions.width, client.field_1772.field_2000));

        animatedScroll = MathUtils.lerp(animatedScroll, scroll, 8);

        Scale.renderScaled(() -> {
            client.field_1772.method_30883(matrixStack, text, textPos.field_1343, textPos.field_1342, -1);
        }, new FloatRectangle(textPos.field_1343, textPos.field_1342, client.field_1772.method_27525(text), client.field_1772.field_2000), 1.25f);

        float offset = 4;

        Scissor.push();

        FloatRectangle rectPos = new FloatRectangle(0, positions.y + offset, client.method_22683().method_4486(), positions.height - 10);

        Scissor.setFromComponentCoordinates(rectPos.x, positions.y + 18, rectPos.width, rectPos.height - 14);

        offset += 12;

        for (ItemRenderer renderer : renderers) {
            renderer.setPosition(new FloatRectangle(positions.x + 3, positions.y, positions.width - 6, 18));
            offset -= renderer.getHeight() + 3;

            renderer.scroll = animatedScroll;
            renderer.render(matrixStack);
        }

        Scissor.pop();

        abBindButton.render(matrixStack);
        autoSetupBindButton.render(matrixStack);
        timedAutoSetup.render(matrixStack);

        updateHeight();

        { // RENDER ALLOCATED
            List<ItemRenderer> allocatedRenderers = renderers.stream()
                    .filter(itemRenderer1 -> itemRenderer1.allocated)
                    .toList();

            if (!allocatedRenderers.isEmpty()) {
                FloatRectangle renderPosition = new FloatRectangle(this.positions.x + this.positions.width + 30, this.positions.y, 180, 55);

                Blur.register(() -> Rounds.drawRound(renderPosition.x, renderPosition.y, renderPosition.width, renderPosition.height, 8, Color.BLACK));
                Blur.draw(4, ColorUtility.getColorComps(new Color(0x717171)));

                class_2585 allocatedText = new class_2585("Выделено предметов: " + allocatedRenderers.size() + "/" + renderers.size());
                class_241 textPosition = MathUtils.getCenteredTextPosition(allocatedText, new FloatRectangle(renderPosition.x, renderPosition.y, renderPosition.width, client.field_1772.field_2000 + 4));

                client.field_1772.method_30883(matrixStack, allocatedText, textPosition.field_1343, textPosition.field_1342, -1);
                buyPriceField.render(matrixStack);
                sellPrice.render(matrixStack);
            }
        }

        scroll = class_3532.method_15363(scroll, offset, 0);
    }

    private void updateHeight() {
        float offset = 22;

        for (ItemRenderer renderer : renderers) {
            renderer.offset = offset;
            offset += renderer.getHeight() + 3;
        }
    }

    @Override
    public void mouseClicked(int button) {
        class_241 mousePos = MathUtils.getMousePos();
        double mouseX = mousePos.field_1343;
        double mouseY = mousePos.field_1342;

        FloatRectangle renderPosition = new FloatRectangle(this.positions.x + this.positions.width + 30, this.positions.y, 180, 120);

        List<ItemRenderer> allocatedRenderers = renderers.stream()
                .filter(itemRenderer1 -> itemRenderer1.allocated)
                .toList();

        if (renderPosition.contains(mouseX, mouseY) && !allocatedRenderers.isEmpty()) {
            buyPriceField.mouseClicked(mouseX, mouseY, button);
            sellPrice.mouseClicked(mouseX, mouseY, button);

            return;
        }

        for (ItemRenderer renderer : renderers) {
            renderer.allocated = false;
        }

        FloatRectangle rectPos = new FloatRectangle(0, positions.y + 4, client.method_22683().method_4486(), positions.height - 10);

        for (ItemRenderer renderer : renderers) {
            FloatRectangle rendererPos = renderer.getPosition().offset(0, renderer.offset + animatedScroll);

            if (!rectPos.contains(rendererPos.x, rendererPos.y)) continue;

            renderer.mouseClicked(mouseX, mouseY, button);
        }

        abBindButton.mouseClicked(mouseX, mouseY, button);
        autoSetupBindButton.mouseClicked(mouseX, mouseY, button);
        timedAutoSetup.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public void mouseReleased(int button) {

    }

    @Override
    public void charTyped(char codePoint) {
        buyPriceField.charTyped(codePoint);
        sellPrice.charTyped(codePoint);

        FloatRectangle rectPos = new FloatRectangle(0, positions.y + 4, client.method_22683().method_4486(), positions.height - 10);

        for (ItemRenderer renderer : renderers) {
            FloatRectangle rendererPos = renderer.getPosition().offset(0, renderer.offset + animatedScroll);

            if (!rectPos.contains(rendererPos.x, rendererPos.y)) {
                continue;
            }

            renderer.charTyped(codePoint);
        }
    }

    @Override
    public void mouseScrolled(double amount) {
        scroll += (float) (amount * 16);
    }

    @Override
    public void keyPressed(int keyCode) {
        buyPriceField.keyPressed(keyCode);
        sellPrice.keyPressed(keyCode);

        FloatRectangle rectPos = new FloatRectangle(0, positions.y + 4, client.method_22683().method_4486(), positions.height - 10);

        for (ItemRenderer renderer : renderers) {
            FloatRectangle rendererPos = renderer.getPosition().offset(0, renderer.offset + animatedScroll);

            if (!rectPos.contains(rendererPos.x, rendererPos.y)) {
                continue;
            }

            renderer.keyPressed(keyCode);
        }

        if (abBinding) {
            abBinding = false;
            SpookyBuy.getInstance().setAbKey(keyCode);
            abBindButton.setTitle(class_2561.method_30163("Автобай: " + KeyUtil.getKey(SpookyBuy.getInstance().getAbKey())));
        }

        if (autoSetupBinding) {
            autoSetupBinding = false;
            SpookyBuy.getInstance().setAutoSetupKey(keyCode);
            autoSetupBindButton.setTitle(class_2561.method_30163("АвтоСетап: " + KeyUtil.getKey(SpookyBuy.getInstance().getAutoSetupKey())));
        }
    }

    private final IconRenderer iconRenderer = new IconRenderer("АвтоБай") {
        @Override
        public void render(class_4587 matrixStack) {
            FloatRectangle positions = this.getPositions();

            Rounds.drawRound(positions.x, positions.y, positions.width, positions.height, 4, Color.BLACK);

            class_241 center = MathUtils.getCenteredTextPosition(class_2561.method_30163(this.getTitle()), positions);

            client.field_1772.method_1720(matrixStack, this.getTitle(), center.field_1343 + 0.5f, center.field_1342 + 0.5f, Pages.getCurrent() == Pages.ITEMS.getPage() ? Color.GREEN.getRGB() : -1);
        }

        @Override
        public void mouseClicked(int button) {
            class_241 mousePos = MathUtils.getMousePos();

            if (getPositions().contains(mousePos.field_1343, mousePos.field_1342)) {
                Pages.setCurrent(Pages.ITEMS.getPage());
                Pages.ITEMS.getPage().translateAnimation.animate(0, 0.8, Easings.BACK_OUT);
                Pages.PARSER.getPage().translateAnimation.animate(client.method_22683().method_4486() + 500, 0.8, Easings.BACK_IN);
            }
        }
    };

    @Override
    public IconRenderer getIconRenderer() {
        return iconRenderer;
    }
}
