package ru.nedan.spookybuy.screen.setting.page.inst;

import ru.nedan.neverapi.animation.util.Easings;
import ru.nedan.neverapi.gl.Scale;
import ru.nedan.neverapi.gl.Scissor;
import ru.nedan.neverapi.gui.Button;
import ru.nedan.neverapi.math.FloatRectangle;
import ru.nedan.neverapi.math.MathUtils;
import ru.nedan.neverapi.shader.Blur;
import ru.nedan.neverapi.shader.ColorUtility;
import ru.nedan.neverapi.shader.Rounds;
import ru.nedan.spookybuy.autobuy.autoparse.coefficient.Coefficient;
import ru.nedan.spookybuy.screen.setting.CoefficientRenderer;
import ru.nedan.spookybuy.screen.setting.page.Page;
import ru.nedan.spookybuy.screen.setting.page.Pages;
import ru.nedan.spookybuy.screen.setting.page.icon.IconRenderer;

import java.awt.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import net.minecraft.class_241;
import net.minecraft.class_2561;
import net.minecraft.class_3532;
import net.minecraft.class_4587;

public class ParserPage extends Page {

    private static ParserPage instance;

    private FloatRectangle positions, original;
    private final List<CoefficientRenderer> renderers = new ArrayList<>();

    public ParserPage() {
        instance = this;
    }

    public static Page getInstance() {
        if (instance == null) new ParserPage();

        return instance;
    }

    public float scroll, animatedScroll;

    private Button add;

    @Override
    public void init() {
        float width = 200;
        float height = 220;

        positions = MathUtils.getCenteredPosition(width, height);
        original = MathUtils.getCenteredPosition(width, height);

        if (Pages.getCurrent() != this) {
            translateAnimation.setToValue(client.method_22683().method_4486() + 500).setValue(client.method_22683().method_4486() + 500);
        }

        add = new Button(class_2561.method_30163("Добавить"), new FloatRectangle(positions.x, positions.y + positions.height + 4, positions.width, 16), (b) -> {
            Coefficient.getAll().add(Coefficient.createDefault());
            updateCoefficients();
        }, Collections.singletonList(
                class_2561.method_30163("Добавить новый коэффициент")
        ));

        updateCoefficients();
    }

    @Override
    public void render(class_4587 matrixStack) {
        translateAnimation.update();
        positions = original.offset((float) translateAnimation.getValue(), 0);

        add.updatePositions(positions.x, positions.y + positions.height + 4, positions.width, 16);
        Blur.register(() -> Rounds.drawRound(positions.x, positions.y, positions.width, positions.height, 8, Color.BLACK));
        Blur.draw(4, ColorUtility.getColorComps(new Color(0x717171)));

        animatedScroll = MathUtils.lerp(animatedScroll, scroll, 8);
        class_2561 text = class_2561.method_30163("Авто Сетап");
        class_241 textPos = MathUtils.getCenteredTextPosition(text, new FloatRectangle(positions.x, positions.y + 4, positions.width, client.field_1772.field_2000));

        float offset = 4;

        Scale.renderScaled(() -> client.field_1772.method_30883(matrixStack, text, textPos.field_1343, textPos.field_1342, -1), new FloatRectangle(textPos.field_1343, textPos.field_1342, client.field_1772.method_27525(text), client.field_1772.field_2000), 1.25f);

        FloatRectangle rectPos = new FloatRectangle(0, positions.y + offset, client.method_22683().method_4486(), positions.height - 10);

        add.render(matrixStack);

        Scissor.push();
        Scissor.setFromComponentCoordinates(rectPos.x, positions.y + 18, rectPos.width, rectPos.height - 14);

        offset += 12;

        for (CoefficientRenderer renderer : renderers) {
            renderer.setPositions(new FloatRectangle(positions.x + 3, positions.y, positions.width - 6, 18));
            offset -= renderer.getHeight() + 3;
            renderer.render(matrixStack);

            renderer.scroll = animatedScroll;
        }

        updateHeight();
        Scissor.pop();

        scroll = class_3532.method_15363(scroll, offset, 0);
    }

    private void updateHeight() {
        float offset = 22;

        for (CoefficientRenderer renderer : renderers) {
            renderer.offset = offset;
            offset += renderer.getHeight() + 3;
        }
    }

    @Override
    public void mouseClicked(int button) {
        for (CoefficientRenderer renderer : renderers) renderer.mouseClicked(button);

        class_241 mouse = MathUtils.getMousePos();
        add.mouseClicked(mouse.field_1343, mouse.field_1342, button);
    }

    @Override
    public void mouseReleased(int button) {

    }

    @Override
    public void charTyped(char codePoint) {
        for (CoefficientRenderer renderer : renderers) renderer.charTyped(codePoint);
    }

    @Override
    public void keyPressed(int keyCode) {
        for (CoefficientRenderer renderer : renderers) renderer.keyPressed(keyCode);
    }

    @Override
    public void mouseScrolled(double amount) {
        scroll += (float) (amount * 16);
    }

    private void updateCoefficients() {
        renderers.clear();

        float offset = 22;
        for (Coefficient coefficient : Coefficient.getAll()) {
            CoefficientRenderer renderer = new CoefficientRenderer(new FloatRectangle(positions.x + 3, positions.y, positions.width - 6, 18), coefficient, offset);
            renderers.add(renderer);
            offset += renderer.getHeight() + 3;
        }
    }

    private final IconRenderer iconRenderer = new IconRenderer("АвтоСетап") {
        @Override
        public void render(class_4587 matrixStack) {
            FloatRectangle positions = this.getPositions();

            Rounds.drawRound(positions.x, positions.y, positions.width, positions.height, 4, Color.BLACK);

            class_241 center = MathUtils.getCenteredTextPosition(class_2561.method_30163(this.getTitle()), positions);

            client.field_1772.method_1720(matrixStack, this.getTitle(), center.field_1343 + 0.5f, center.field_1342 + 0.5f, Pages.getCurrent() == Pages.PARSER.getPage() ? Color.GREEN.getRGB() : -1);
        }

        @Override
        public void mouseClicked(int button) {
            class_241 mousePos = MathUtils.getMousePos();

            if (getPositions().contains(mousePos.field_1343, mousePos.field_1342)) {
                Pages.setCurrent(Pages.PARSER.getPage());
                Pages.PARSER.getPage().translateAnimation.animate(0, 0.8, Easings.BACK_OUT);
                Pages.ITEMS.getPage().translateAnimation.animate(client.method_22683().method_4486() + 500, 0.8, Easings.BACK_IN);
            }
        }
    };

    @Override
    public IconRenderer getIconRenderer() {
        return iconRenderer;
    }
}
