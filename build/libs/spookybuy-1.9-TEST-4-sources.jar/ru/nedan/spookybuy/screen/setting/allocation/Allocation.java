package ru.nedan.spookybuy.screen.setting.allocation;

import lombok.Getter;
import net.minecraft.class_241;
import ru.nedan.neverapi.math.FloatRectangle;
import ru.nedan.neverapi.math.MathUtils;

public class Allocation {
    @Getter
    private FloatRectangle rectangle;

    private class_241 start;

    public void init() {
        start = MathUtils.getMousePos();

        rectangle = new FloatRectangle(start.field_1343, start.field_1342, 0, 0);
    }

    public void mouseMoved() {
        if (start == null) return;

        class_241 current = MathUtils.getMousePos();

        float x1 = Math.min(start.field_1343, current.field_1343);
        float y1 = Math.min(start.field_1342, current.field_1342);
        float x2 = Math.max(start.field_1343, current.field_1343);
        float y2 = Math.max(start.field_1342, current.field_1342);

        rectangle = new FloatRectangle(x1, y1, x2 - x1, y2 - y1);
    }

    public void stop() {
        start = null;
        rectangle = null;
    }
}