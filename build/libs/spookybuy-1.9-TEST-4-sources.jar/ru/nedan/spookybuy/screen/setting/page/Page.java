package ru.nedan.spookybuy.screen.setting.page;

import net.minecraft.class_310;
import net.minecraft.class_4587;
import ru.nedan.neverapi.animation.Animation;
import ru.nedan.spookybuy.SpookyBuy;
import ru.nedan.spookybuy.screen.setting.SpookyBuyGui;
import ru.nedan.spookybuy.screen.setting.page.icon.IconRenderer;

public abstract class Page {

    protected static final class_310 client = class_310.method_1551();
    protected static final SpookyBuyGui gui = SpookyBuy.getInstance().getGui();

    public Animation translateAnimation = new Animation();

    public abstract void init();
    public abstract void render(class_4587 matrixStack);
    public abstract void mouseClicked(int button);
    public abstract void mouseReleased(int button);
    public abstract void charTyped(char codePoint);
    public abstract void keyPressed(int keyCode);
    public abstract void mouseScrolled(double amount);

    public abstract IconRenderer getIconRenderer();

}
