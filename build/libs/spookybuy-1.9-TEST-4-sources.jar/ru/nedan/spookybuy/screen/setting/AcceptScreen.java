package ru.nedan.spookybuy.screen.setting;

import net.minecraft.class_241;
import net.minecraft.class_2561;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_4587;
import ru.nedan.neverapi.math.FloatRectangle;
import ru.nedan.neverapi.math.MathUtils;

public class AcceptScreen extends class_437 {

    final class_437 prev;
    final class_2561 acceptString;
    final Runnable[] actions;

    public AcceptScreen(class_437 prev, class_2561 acceptString, Runnable[] actions) {
        super(class_2561.method_30163("AcceptScreen"));
        this.prev = prev;
        this.acceptString = acceptString;
        this.actions = actions;
    }

    @Override
    protected void method_25426() {
        super.method_25426();

        FloatRectangle centerPosition = MathUtils.getCenteredPosition(200, 20);

        method_25411(new class_4185((int) centerPosition.x, (int) centerPosition.y, 100, 20, class_2561.method_30163("Да"), (butt) -> {
            actions[0].run();
            field_22787.method_1507(prev);
        }));

        method_25411(new class_4185((int) centerPosition.x + 110, (int) centerPosition.y, 100, 20, class_2561.method_30163("Нет"), (butt) -> {
            actions[1].run();
            field_22787.method_1507(prev);
        }));
    }

    @Override
    public void method_25394(class_4587 matrices, int mouseX, int mouseY, float delta) {
        super.method_25420(matrices);
        super.method_25394(matrices, mouseX, mouseY, delta);

        class_241 textPos = MathUtils.getCenteredTextPosition(acceptString, new FloatRectangle(0, 0, field_22787.method_22683().method_4486(), field_22787.method_22683().method_4502()).offset(0, -40));

        field_22787.field_1772.method_30881(matrices, acceptString, textPos.field_1343, textPos.field_1342, -1);
    }
}
