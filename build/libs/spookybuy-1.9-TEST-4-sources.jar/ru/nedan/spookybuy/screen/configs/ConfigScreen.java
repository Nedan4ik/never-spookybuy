package ru.nedan.spookybuy.screen.configs;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import org.apache.commons.lang3.RandomStringUtils;
import ru.nedan.neverapi.async.AsyncRunManager;
import ru.nedan.spookybuy.event.EventServerResponse;
import ru.nedan.spookybuy.util.ws.Client;

import java.util.HashMap;
import java.util.Map;
import java.util.function.BiConsumer;
import net.minecraft.class_124;
import net.minecraft.class_1263;
import net.minecraft.class_1277;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1707;
import net.minecraft.class_1713;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2519;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_2585;
import net.minecraft.class_3917;
import net.minecraft.class_476;

public class ConfigScreen extends class_476 {

    public final Map<String, String> keys = new HashMap<>();

    public ConfigScreen(class_1661 inventory, BiConsumer<Integer, Integer> ijConsumer) {
        super(createCustomContainerHandler(inventory, -1, 6, ijConsumer), inventory, new class_2585("Never SpookyBuy — Конфиги"));
    }

    @Override
    protected void method_25426() {
        super.method_25426();

        AsyncRunManager.once(EventServerResponse.class, e -> {
            e.setUsed(true);
            JsonArray configs = e.asJson().getAsJsonArray("message");
            class_1707 screenHandler = this.method_17577();

            int i = 0;
            for (JsonElement element : configs) {
                JsonObject object = element.getAsJsonObject();

                String itemName = object.get("itemName").getAsString();
                String description = object.get("description").getAsString();
                String discordLink = object.get("discordLink").getAsString();
                String cloudKey = object.get("cloudKey").getAsString();
                int usersSize = object.get("usersSize").getAsInt();

                class_1799 stack = new class_1799(class_1802.field_8137);
                class_2487 nbt = stack.method_7948();

                class_2487 display = new class_2487();

                class_2583 defaultStyle = class_2583.field_24360.method_10978(false);

                class_2583 nameStyle = defaultStyle.method_10977(class_124.field_1075).method_10982(true);
                class_2583 descStyle = defaultStyle.method_10977(class_124.field_1080);
                class_2583 actionStyle = defaultStyle.method_10977(class_124.field_1065);

                display.method_10582("Name", class_2561.class_2562.method_10867(new class_2585(itemName).method_10862(nameStyle)));

                class_2499 loreList = new class_2499();
                loreList.add(class_2519.method_23256(class_2561.class_2562.method_10867(new class_2585(description).method_10862(descStyle))));
                loreList.add(class_2519.method_23256(class_2561.class_2562.method_10867(new class_2585("ЛКМ — загрузить").method_10862(actionStyle))));
                loreList.add(class_2519.method_23256(class_2561.class_2562.method_10867(new class_2585("ПКМ — перейти в Discord").method_10862(actionStyle))));
                loreList.add(class_2519.method_23256(class_2561.class_2562.method_10867(new class_2585("СКМ Авто-загрузка: ").method_10862(actionStyle).method_10852(new class_2585(autoInject(itemName) ? "§aвключено" : "§cвыключено")))));
                loreList.add(class_2519.method_23256(class_2561.class_2562.method_10867(new class_2585("Пользователей: ").method_10862(actionStyle).method_10852(new class_2585("" + usersSize).method_10862(class_2583.field_24360.method_27706(class_124.field_1075))))));
                display.method_10566("Lore", loreList);
                display.method_10566("Lore", loreList);
                nbt.method_10566("display", display);

                String randomString = RandomStringUtils.randomAlphabetic(15);

                nbt.method_10582("discordLink", discordLink);
                nbt.method_10582("key", randomString);
                nbt.method_10582("authorName", itemName);
                stack.method_7980(nbt);
                screenHandler.method_7619(i, stack);
                i++;
                keys.put(randomString, cloudKey);
            }
        }, e -> e.asJson().isJsonObject() && e.asJson().has("type") && e.asJson().get("type").getAsString().equalsIgnoreCase("configs"));

        JsonObject object = new JsonObject();
        object.addProperty("action", "askConfigs");
        Client.getInstance().sendMessage(object.toString());
    }

    public static class_1707 createCustomContainerHandler(class_1661 playerInventory, int syncId, int rows, BiConsumer<Integer, Integer> ijConsumer) {
        class_1263 containerInventory = new class_1277(9 * rows);
        return new class_1707(class_3917.field_17327, syncId, playerInventory, containerInventory, rows) {
            @Override
            public class_1799 method_7593(int i, int j, class_1713 actionType, class_1657 playerEntity) {
                ijConsumer.accept(i, j);

                return class_1799.field_8037;
            }
        };
    }

    private static final HashMap<String, Boolean> flags = new HashMap<>();

    public static void toggleAuthor(String s) {
        if (!flags.containsKey(s)) flags.put(s, false);
        else flags.replace(s, !flags.get(s));
    }

    public static boolean autoInject(String authorName) {
        return flags.getOrDefault(authorName, true);
    }
}
